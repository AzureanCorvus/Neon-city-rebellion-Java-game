
import { type Config } from "tailwindcss";

const config: Config = {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        'cyber-purple': 'rgb(155, 135, 245)',
        'cyber-blue': 'rgb(14, 165, 233)',
        'cyber-red': 'rgb(239, 68, 68)',
        'cyber-green': 'rgb(16, 185, 129)',
        'cyber-orange': 'rgb(249, 115, 22)',
        'cyber-pink': 'rgb(236, 72, 153)',
        'cyber-dark': 'rgb(26, 31, 44)',
        'cyber-black': 'rgb(13, 15, 22)',
      },
      animation: {
        'neon-pulse': 'neon-pulse 2s infinite alternate',
        'scanning': 'scanning 10s infinite linear',
      },
      keyframes: {
        'neon-pulse': {
          '0%': {
            opacity: '0.5',
            boxShadow: '0 0 5px currentColor',
          },
          '100%': {
            opacity: '1',
            boxShadow: '0 0 15px currentColor, 0 0 20px currentColor',
          },
        },
        'scanning': {
          '0%': { top: '0' },
          '100%': { top: '100%' },
        },
      },
      backgroundImage: {
        'cyber-grid': `linear-gradient(rgba(155, 135, 245, 0.15) 1px, transparent 1px),
                       linear-gradient(90deg, rgba(155, 135, 245, 0.15) 1px, transparent 1px)`,
        'scanning-line': 'linear-gradient(90deg, transparent, var(--cyber-purple), transparent)',
      },
    },
  },
  plugins: [],
};

export default config;
