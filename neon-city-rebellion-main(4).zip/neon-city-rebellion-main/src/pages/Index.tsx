
import GameContainer from "@/components/GameContainer";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col bg-cyber-black">
      <header className="px-4 py-6 text-center">
        <h1 className="text-5xl font-bold text-cyber-purple animate-neon-pulse">NEON CITY REBELLION</h1>
        <p className="text-lg text-white/80 mt-2">A cyberpunk shooter set in a dystopian future</p>
      </header>
      
      <main className="flex-1 flex flex-col items-center justify-center">
        <GameContainer />
      </main>
      
      <footer className="p-4 text-center text-white/60 border-t border-cyber-purple/20">
        <p className="text-sm">
          Use arrow keys to move and space to shoot. Collect power-ups to restore health, ammo or upgrade weapons.
        </p>
      </footer>
    </div>
  );
};

export default Index;
