
package com.neoncityrebellion.utils;

import com.neoncityrebellion.entities.Entity;

/**
 * Handles collision detection between entities.
 */
public class CollisionHandler {
    
    /**
     * Checks if two entities are colliding
     * @param e1 First entity
     * @param e2 Second entity
     * @return True if entities are colliding
     */
    public static boolean checkCollision(Entity e1, Entity e2) {
        if (!e1.isActive() || !e2.isActive()) {
            return false;
        }
        
        return e1.getBounds().intersects(e2.getBounds());
    }
}
