
package com.neoncityrebellion.utils;

/**
 * Constants used throughout the game.
 */
public class Constants {
    // Screen settings
    public static final int SCREEN_WIDTH = 800;
    public static final int SCREEN_HEIGHT = 600;
    
    // Entity dimensions
    public static final int PLAYER_WIDTH = 64;
    public static final int PLAYER_HEIGHT = 64;
    public static final int ENEMY_WIDTH = 48;
    public static final int ENEMY_HEIGHT = 48;
    public static final int BULLET_WIDTH = 16;
    public static final int BULLET_HEIGHT = 16;
    public static final int POWERUP_WIDTH = 32;
    public static final int POWERUP_HEIGHT = 32;
    
    // Game states
    public static final int MENU_STATE = 0;
    public static final int PLAY_STATE = 1;
    public static final int GAME_OVER_STATE = 2;
    
    // Player constants
    public static final int PLAYER_SPEED = 5;
    public static final int PLAYER_MAX_HEALTH = 100;
    public static final int BULLET_SPEED = 10;
    public static final int SHOOTING_COOLDOWN = 20; // frames
    
    // Enemy constants
    public static final int NORMAL_ENEMY_SPEED = 2;
    public static final int FAST_ENEMY_SPEED = 4;
    public static final int TANK_ENEMY_SPEED = 1;
    public static final int NORMAL_ENEMY_HEALTH = 30;
    public static final int FAST_ENEMY_HEALTH = 15;
    public static final int TANK_ENEMY_HEALTH = 100;
    
    // Score values
    public static final int NORMAL_ENEMY_SCORE = 100;
    public static final int FAST_ENEMY_SCORE = 150;
    public static final int TANK_ENEMY_SCORE = 300;
}
