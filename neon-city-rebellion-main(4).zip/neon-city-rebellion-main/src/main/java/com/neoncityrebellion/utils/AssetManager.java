
package com.neoncityrebellion.utils;

import javax.imageio.ImageIO;
import javax.sound.sampled.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

/**
 * Manages loading and caching of game assets (images, sounds).
 */
public class AssetManager {
    
    // Image caches
    private static final HashMap<String, BufferedImage> sprites = new HashMap<>();
    private static BufferedImage[] playerSprites;
    private static BufferedImage[] enemySprites;
    private static BufferedImage[] powerUpSprites;
    private static BufferedImage playerBulletSprite;
    private static BufferedImage enemyBulletSprite;
    
    // Sound caches
    private static final HashMap<String, Clip> sounds = new HashMap<>();
    private static Clip musicClip;
    
    /**
     * Loads menu assets
     */
    public static void loadMenuAssets() {
        try {
            // Load menu sounds
            loadSound("menu_select.wav");
            loadSound("menu_confirm.wav");
        } catch (Exception e) {
            System.err.println("Error loading menu assets: " + e.getMessage());
        }
    }
    
    /**
     * Loads game assets
     */
    public static void loadGameAssets() {
        try {
            // Load player sprites
            playerSprites = new BufferedImage[2];
            playerSprites[0] = loadImage("player_1.png");
            playerSprites[1] = loadImage("player_2.png");
            
            // Load enemy sprites
            enemySprites = new BufferedImage[3];
            enemySprites[0] = loadImage("enemy_normal.png");
            enemySprites[1] = loadImage("enemy_fast.png");
            enemySprites[2] = loadImage("enemy_tank.png");
            
            // Load bullet sprites
            playerBulletSprite = loadImage("player_bullet.png");
            enemyBulletSprite = loadImage("enemy_bullet.png");
            
            // Load power-up sprites
            powerUpSprites = new BufferedImage[3];
            powerUpSprites[0] = loadImage("powerup_health.png");
            powerUpSprites[1] = loadImage("powerup_rapid.png");
            powerUpSprites[2] = loadImage("powerup_shield.png");
            
            // Load game sounds
            loadSound("player_shoot.wav");
            loadSound("enemy_shoot.wav");
            loadSound("player_hit.wav");
            loadSound("hit.wav");
            loadSound("enemy_explosion.wav");
            loadSound("powerup.wav");
            loadSound("wave_start.wav");
            loadSound("game_over.wav");
            
            // Load music
            loadMusic("game_music.wav");
        } catch (Exception e) {
            System.err.println("Error loading game assets: " + e.getMessage());
        }
    }
    
    /**
     * Loads an image
     * @param filename Image filename
     * @return The loaded image
     */
    private static BufferedImage loadImage(String filename) {
        if (sprites.containsKey(filename)) {
            return sprites.get(filename);
        }
        
        try {
            // For simplicity, we'll create placeholder images for missing assets
            // In a real game, you'd load assets from the resources directory
            
            // Create placeholder image
            BufferedImage placeholder = new BufferedImage(32, 32, BufferedImage.TYPE_INT_ARGB);
            sprites.put(filename, placeholder);
            
            // Try to load real image if it exists
            try {
                File file = new File("src/main/resources/assets/images/" + filename);
                if (file.exists()) {
                    BufferedImage image = ImageIO.read(file);
                    sprites.put(filename, image);
                    return image;
                }
            } catch (IOException e) {
                System.err.println("Error loading image " + filename + ": " + e.getMessage());
            }
            
            return placeholder;
        } catch (Exception e) {
            System.err.println("Error creating placeholder for " + filename + ": " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Loads a sound
     * @param filename Sound filename
     */
    private static void loadSound(String filename) {
        if (sounds.containsKey(filename)) {
            return;
        }
        
        try {
            File soundFile = new File("src/main/resources/assets/sounds/" + filename);
            
            if (soundFile.exists()) {
                AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFile);
                Clip clip = AudioSystem.getClip();
                clip.open(audioIn);
                sounds.put(filename, clip);
            } else {
                System.out.println("Sound file not found: " + filename);
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.err.println("Error loading sound " + filename + ": " + e.getMessage());
        }
    }
    
    /**
     * Loads music file
     * @param filename Music filename
     */
    private static void loadMusic(String filename) {
        try {
            File musicFile = new File("src/main/resources/assets/music/" + filename);
            
            if (musicFile.exists()) {
                AudioInputStream audioIn = AudioSystem.getAudioInputStream(musicFile);
                musicClip = AudioSystem.getClip();
                musicClip.open(audioIn);
            } else {
                System.out.println("Music file not found: " + filename);
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.err.println("Error loading music " + filename + ": " + e.getMessage());
        }
    }
    
    /**
     * Plays a sound effect
     * @param filename Sound filename
     */
    public static void playSound(String filename) {
        Clip clip = sounds.get(filename);
        
        if (clip != null) {
            clip.setFramePosition(0);
            clip.start();
        }
    }
    
    /**
     * Plays music
     * @param filename Music filename
     * @param loop Whether to loop the music
     */
    public static void playMusic(String filename, boolean loop) {
        if (musicClip != null) {
            musicClip.stop();
            
            musicClip.setFramePosition(0);
            if (loop) {
                musicClip.loop(Clip.LOOP_CONTINUOUSLY);
            } else {
                musicClip.start();
            }
        }
    }
    
    /**
     * Stops the music
     */
    public static void stopMusic() {
        if (musicClip != null) {
            musicClip.stop();
        }
    }
    
    // Getters for sprites
    public static BufferedImage[] getPlayerSprites() { return playerSprites; }
    
    public static BufferedImage getEnemySprite(int type) { 
        if (enemySprites != null && type >= 0 && type < enemySprites.length) {
            return enemySprites[type];
        }
        return null;
    }
    
    public static BufferedImage getPowerUpSprite(int type) {
        if (powerUpSprites != null && type >= 0 && type < powerUpSprites.length) {
            return powerUpSprites[type];
        }
        return null;
    }
    
    public static BufferedImage getPlayerBulletSprite() { return playerBulletSprite; }
    
    public static BufferedImage getEnemyBulletSprite() { return enemyBulletSprite; }
}
