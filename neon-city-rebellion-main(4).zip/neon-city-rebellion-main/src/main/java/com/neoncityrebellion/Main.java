
package com.neoncityrebellion;

import com.neoncityrebellion.game.GameWindow;

/**
 * Main entry point for the Neon City Rebellion game.
 * Initializes and starts the game window.
 */
public class Main {
    public static void main(String[] args) {
        // Start the game on the Event Dispatch Thread
        javax.swing.SwingUtilities.invokeLater(() -> {
            GameWindow gameWindow = new GameWindow();
            gameWindow.setVisible(true);
        });
    }
}
