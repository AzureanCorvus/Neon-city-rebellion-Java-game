
package com.neoncityrebellion.game;

import com.neoncityrebellion.game.states.GameStateManager;
import com.neoncityrebellion.input.KeyHandler;
import com.neoncityrebellion.utils.Constants;

import javax.swing.*;
import java.awt.*;

/**
 * Main game panel that handles rendering and the game loop.
 * Implements Runnable to run the game loop in a separate thread.
 */
public class GamePanel extends JPanel implements Runnable {
    
    // Screen settings
    private final int screenWidth = Constants.SCREEN_WIDTH;
    private final int screenHeight = Constants.SCREEN_HEIGHT;
    
    // Input handler
    private final KeyHandler keyHandler = new KeyHandler();
    
    // Game state manager
    private final GameStateManager gsm = new GameStateManager();
    
    // Game thread
    private Thread gameThread;
    
    // FPS control
    private final int FPS = 60;
    
    public GamePanel() {
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.BLACK);
        this.setDoubleBuffered(true);
        this.addKeyListener(keyHandler);
        this.setFocusable(true);
    }
    
    /**
     * Starts the game thread
     */
    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }
    
    /**
     * Game loop implementation using sleep for timing
     */
    @Override
    public void run() {
        double drawInterval = 1000000000.0 / FPS; // 1 second in nanoseconds divided by FPS
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        long timer = 0;
        int drawCount = 0;
        
        // Game loop
        while (gameThread != null) {
            currentTime = System.nanoTime();
            
            delta += (currentTime - lastTime) / drawInterval;
            timer += (currentTime - lastTime);
            lastTime = currentTime;
            
            if (delta >= 1) {
                // Update game state
                update();
                
                // Repaint the screen
                repaint();
                
                delta--;
                drawCount++;
            }
            
            // Display FPS
            if (timer >= 1000000000) {
                System.out.println("FPS: " + drawCount);
                drawCount = 0;
                timer = 0;
            }
        }
    }
    
    /**
     * Updates game logic
     */
    public void update() {
        gsm.update(keyHandler);
    }
    
    /**
     * Renders the game
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        Graphics2D g2d = (Graphics2D) g;
        
        // Enable anti-aliasing for smoother graphics
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Render the current game state
        gsm.render(g2d);
        
        g2d.dispose();
    }
}
