
package com.neoncityrebellion.game.states;

import com.neoncityrebellion.input.KeyHandler;
import com.neoncityrebellion.utils.Constants;

import java.awt.*;

/**
 * Game over state.
 */
public class GameOverState extends GameState {
    
    private int finalScore;
    private int finalWave;
    private final Color neonPurple = new Color(155, 135, 245);
    private final Color neonRed = new Color(239, 68, 68);
    
    public GameOverState(GameStateManager gsm) {
        super(gsm);
    }
    
    @Override
    public void init() {
        // If PlayState exists, get the final score
        if (gsm.getClass().getFields().length > 1) {
            try {
                Object playState = gsm.getClass().getField("gameStates").get(gsm);
                if (playState instanceof PlayState) {
                    PlayState ps = (PlayState) playState;
                    finalScore = ps.getScore();
                    finalWave = ps.getCurrentWave();
                }
            } catch (Exception e) {
                finalScore = 0;
                finalWave = 0;
            }
        }
    }
    
    @Override
    public void update(KeyHandler keyHandler) {
        if (keyHandler.enterPressed) {
            keyHandler.enterPressed = false;
            gsm.setState(Constants.MENU_STATE);
        }
        
        if (keyHandler.escapePressed) {
            keyHandler.escapePressed = false;
            System.exit(0);
        }
    }
    
    @Override
    public void render(Graphics2D g) {
        // Draw background
        drawCyberpunkBackground(g);
        
        // Draw game over text
        g.setFont(new Font("OCR A Extended", Font.BOLD, 48));
        g.setColor(neonRed);
        String gameOverText = "GAME OVER";
        int gameOverWidth = g.getFontMetrics().stringWidth(gameOverText);
        g.drawString(gameOverText, Constants.SCREEN_WIDTH / 2 - gameOverWidth / 2, 150);
        
        // Draw stats
        g.setFont(new Font("OCR A Extended", Font.PLAIN, 24));
        g.setColor(neonPurple);
        
        String scoreText = "FINAL SCORE: " + finalScore;
        int scoreWidth = g.getFontMetrics().stringWidth(scoreText);
        g.drawString(scoreText, Constants.SCREEN_WIDTH / 2 - scoreWidth / 2, 250);
        
        String waveText = "WAVES SURVIVED: " + finalWave;
        int waveWidth = g.getFontMetrics().stringWidth(waveText);
        g.drawString(waveText, Constants.SCREEN_WIDTH / 2 - waveWidth / 2, 300);
        
        // Draw instructions
        g.setFont(new Font("OCR A Extended", Font.PLAIN, 18));
        g.setColor(Color.WHITE);
        
        String restartText = "PRESS ENTER TO RETURN TO MENU";
        int restartWidth = g.getFontMetrics().stringWidth(restartText);
        g.drawString(restartText, Constants.SCREEN_WIDTH / 2 - restartWidth / 2, 400);
        
        String quitText = "PRESS ESC TO QUIT";
        int quitWidth = g.getFontMetrics().stringWidth(quitText);
        g.drawString(quitText, Constants.SCREEN_WIDTH / 2 - quitWidth / 2, 430);
    }
    
    /**
     * Draws the cyberpunk background
     * @param g Graphics context
     */
    private void drawCyberpunkBackground(Graphics2D g) {
        // Black background
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT);
        
        // Draw grid
        g.setColor(new Color(neonRed.getRed(), neonRed.getGreen(), neonRed.getBlue(), 30));
        
        // Horizontal lines
        for (int y = 0; y < Constants.SCREEN_HEIGHT; y += 30) {
            g.drawLine(0, y, Constants.SCREEN_WIDTH, y);
        }
        
        // Vertical lines
        for (int x = 0; x < Constants.SCREEN_WIDTH; x += 30) {
            g.drawLine(x, 0, x, Constants.SCREEN_HEIGHT);
        }
        
        // Glitch effect
        for (int i = 0; i < 10; i++) {
            int x = (int) (Math.random() * Constants.SCREEN_WIDTH);
            int y = (int) (Math.random() * Constants.SCREEN_HEIGHT);
            int width = (int) (Math.random() * 100) + 50;
            int height = (int) (Math.random() * 10) + 2;
            
            g.setColor(new Color(neonRed.getRed(), neonRed.getGreen(), neonRed.getBlue(), 
                                (int) (Math.random() * 100) + 50));
            g.fillRect(x, y, width, height);
        }
    }
}
