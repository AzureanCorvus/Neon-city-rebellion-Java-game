
package com.neoncityrebellion.game.states;

import com.neoncityrebellion.entities.*;
import com.neoncityrebellion.input.KeyHandler;
import com.neoncityrebellion.utils.AssetManager;
import com.neoncityrebellion.utils.CollisionHandler;
import com.neoncityrebellion.utils.Constants;

import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * Main gameplay state.
 */
public class PlayState extends GameState {
    
    // Game entities
    private Player player;
    private ArrayList<Enemy> enemies;
    private ArrayList<Bullet> playerBullets;
    private ArrayList<Bullet> enemyBullets;
    private ArrayList<PowerUp> powerUps;
    
    // Game state
    private int score;
    private int currentWave;
    private int enemiesRemaining;
    private int waveDelay;
    private boolean waveInProgress;
    private final Random random = new Random();
    
    // HUD elements
    private HUD hud;
    
    // Background effect
    private int scanlinePosition = 0;
    
    public PlayState(GameStateManager gsm) {
        super(gsm);
    }
    
    @Override
    public void init() {
        // Load game assets
        AssetManager.loadGameAssets();
        
        // Initialize game entities
        player = new Player(Constants.SCREEN_WIDTH / 2 - Constants.PLAYER_WIDTH / 2, 
                           Constants.SCREEN_HEIGHT - Constants.PLAYER_HEIGHT * 2, 
                           Constants.PLAYER_WIDTH, 
                           Constants.PLAYER_HEIGHT);
        
        enemies = new ArrayList<>();
        playerBullets = new ArrayList<>();
        enemyBullets = new ArrayList<>();
        powerUps = new ArrayList<>();
        
        // Initialize game state
        score = 0;
        currentWave = 1;
        waveDelay = 180; // 3 seconds at 60 FPS
        waveInProgress = false;
        
        // Initialize HUD
        hud = new HUD(player);
        
        // Start background music
        AssetManager.playMusic("game_music.wav", true);
    }
    
    @Override
    public void update(KeyHandler keyHandler) {
        // Update player
        player.update(keyHandler, playerBullets);
        
        // Update wave system
        updateWaveSystem();
        
        // Update bullets
        updateBullets();
        
        // Update enemies
        updateEnemies();
        
        // Update power-ups
        updatePowerUps();
        
        // Check collisions
        handleCollisions();
        
        // Update HUD
        hud.update();
        
        // Check game over condition
        if (player.getHealth() <= 0) {
            AssetManager.playSound("game_over.wav");
            gsm.setState(Constants.GAME_OVER_STATE);
        }
        
        // Update background effects
        updateBackgroundEffects();
    }
    
    /**
     * Updates the wave system
     */
    private void updateWaveSystem() {
        if (!waveInProgress) {
            if (waveDelay > 0) {
                waveDelay--;
            } else {
                startNewWave();
            }
        } else if (enemies.isEmpty()) {
            waveInProgress = false;
            waveDelay = 180; // 3 seconds at 60 FPS
            currentWave++;
        }
    }
    
    /**
     * Starts a new wave of enemies
     */
    private void startNewWave() {
        waveInProgress = true;
        enemiesRemaining = 5 + currentWave * 2; // More enemies each wave
        
        for (int i = 0; i < enemiesRemaining; i++) {
            spawnEnemy();
        }
        
        AssetManager.playSound("wave_start.wav");
    }
    
    /**
     * Spawns a random enemy type
     */
    private void spawnEnemy() {
        int type = random.nextInt(100);
        int x = random.nextInt(Constants.SCREEN_WIDTH - Constants.ENEMY_WIDTH);
        int y = random.nextInt(Constants.SCREEN_HEIGHT / 3); // Top third of screen
        
        Enemy enemy;
        if (type < 60) {
            // 60% chance for normal enemy
            enemy = new NormalEnemy(x, y, Constants.ENEMY_WIDTH, Constants.ENEMY_HEIGHT);
        } else if (type < 85) {
            // 25% chance for fast enemy
            enemy = new FastEnemy(x, y, Constants.ENEMY_WIDTH, Constants.ENEMY_HEIGHT);
        } else {
            // 15% chance for tank enemy
            enemy = new TankEnemy(x, y, Constants.ENEMY_WIDTH, Constants.ENEMY_HEIGHT);
        }
        
        enemies.add(enemy);
    }
    
    /**
     * Updates all bullets
     */
    private void updateBullets() {
        // Update player bullets
        Iterator<Bullet> pbIt = playerBullets.iterator();
        while (pbIt.hasNext()) {
            Bullet bullet = pbIt.next();
            bullet.update();
            
            // Remove bullets that are off-screen
            if (bullet.getY() < 0) {
                pbIt.remove();
            }
        }
        
        // Update enemy bullets
        Iterator<Bullet> ebIt = enemyBullets.iterator();
        while (ebIt.hasNext()) {
            Bullet bullet = ebIt.next();
            bullet.update();
            
            // Remove bullets that are off-screen
            if (bullet.getY() > Constants.SCREEN_HEIGHT) {
                ebIt.remove();
            }
        }
    }
    
    /**
     * Updates all enemies
     */
    private void updateEnemies() {
        Iterator<Enemy> it = enemies.iterator();
        while (it.hasNext()) {
            Enemy enemy = it.next();
            enemy.update(player, enemyBullets);
            
            // Remove enemies that are off-screen or dead
            if (enemy.getY() > Constants.SCREEN_HEIGHT || enemy.getHealth() <= 0) {
                if (enemy.getHealth() <= 0) {
                    // Add score based on enemy type
                    score += enemy.getScoreValue();
                    AssetManager.playSound("enemy_explosion.wav");
                    
                    // Chance to drop power-up
                    if (random.nextInt(100) < 20) { // 20% chance
                        spawnPowerUp(enemy.getX(), enemy.getY());
                    }
                }
                it.remove();
            }
        }
    }
    
    /**
     * Updates all power-ups
     */
    private void updatePowerUps() {
        Iterator<PowerUp> it = powerUps.iterator();
        while (it.hasNext()) {
            PowerUp powerUp = it.next();
            powerUp.update();
            
            // Remove power-ups that are off-screen
            if (powerUp.getY() > Constants.SCREEN_HEIGHT) {
                it.remove();
            }
        }
    }
    
    /**
     * Spawns a random power-up
     * @param x X coordinate
     * @param y Y coordinate
     */
    private void spawnPowerUp(int x, int y) {
        int type = random.nextInt(3);
        PowerUp powerUp;
        
        switch (type) {
            case 0 -> powerUp = new HealthPowerUp(x, y, Constants.POWERUP_WIDTH, Constants.POWERUP_HEIGHT);
            case 1 -> powerUp = new RapidFirePowerUp(x, y, Constants.POWERUP_WIDTH, Constants.POWERUP_HEIGHT);
            default -> powerUp = new ShieldPowerUp(x, y, Constants.POWERUP_WIDTH, Constants.POWERUP_HEIGHT);
        }
        
        powerUps.add(powerUp);
    }
    
    /**
     * Handles all collisions
     */
    private void handleCollisions() {
        // Player bullets vs enemies
        for (Bullet bullet : playerBullets) {
            for (Enemy enemy : enemies) {
                if (CollisionHandler.checkCollision(bullet, enemy)) {
                    enemy.takeDamage(bullet.getDamage());
                    bullet.setActive(false);
                    AssetManager.playSound("hit.wav");
                }
            }
        }
        
        // Enemy bullets vs player
        for (Bullet bullet : enemyBullets) {
            if (CollisionHandler.checkCollision(bullet, player) && bullet.isActive()) {
                player.takeDamage(bullet.getDamage());
                bullet.setActive(false);
                AssetManager.playSound("player_hit.wav");
            }
        }
        
        // Power-ups vs player
        for (PowerUp powerUp : powerUps) {
            if (CollisionHandler.checkCollision(powerUp, player) && powerUp.isActive()) {
                powerUp.applyEffect(player);
                powerUp.setActive(false);
                AssetManager.playSound("powerup.wav");
            }
        }
        
        // Clean up inactive entities
        playerBullets.removeIf(bullet -> !bullet.isActive());
        enemyBullets.removeIf(bullet -> !bullet.isActive());
        powerUps.removeIf(powerUp -> !powerUp.isActive());
    }
    
    /**
     * Updates background effects
     */
    private void updateBackgroundEffects() {
        scanlinePosition = (scanlinePosition + 1) % (Constants.SCREEN_HEIGHT * 2);
    }
    
    @Override
    public void render(Graphics2D g) {
        // Draw background
        drawCyberpunkBackground(g);
        
        // Draw scanline effect
        drawScanline(g);
        
        // Draw entities
        for (PowerUp powerUp : powerUps) {
            powerUp.render(g);
        }
        
        for (Enemy enemy : enemies) {
            enemy.render(g);
        }
        
        player.render(g);
        
        for (Bullet bullet : playerBullets) {
            bullet.render(g);
        }
        
        for (Bullet bullet : enemyBullets) {
            bullet.render(g);
        }
        
        // Draw HUD
        hud.render(g);
        
        // Draw wave information
        if (!waveInProgress && waveDelay > 0) {
            drawWaveInfo(g);
        }
    }
    
    /**
     * Draws the cyberpunk background
     * @param g Graphics context
     */
    private void drawCyberpunkBackground(Graphics2D g) {
        // Black background
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT);
        
        // Draw grid
        Color gridColor = new Color(155, 135, 245, 40); // Neon purple with alpha
        g.setColor(gridColor);
        
        // Horizontal lines
        for (int y = 0; y < Constants.SCREEN_HEIGHT; y += 30) {
            g.drawLine(0, y, Constants.SCREEN_WIDTH, y);
        }
        
        // Vertical lines
        for (int x = 0; x < Constants.SCREEN_WIDTH; x += 30) {
            g.drawLine(x, 0, x, Constants.SCREEN_HEIGHT);
        }
    }
    
    /**
     * Draws a scanline effect
     * @param g Graphics context
     */
    private void drawScanline(Graphics2D g) {
        int alpha = 40; // Transparency
        int height = 4; // Height of scanline
        
        Color scanlineColor = new Color(155, 135, 245, alpha);
        g.setColor(scanlineColor);
        
        int y = scanlinePosition % Constants.SCREEN_HEIGHT;
        g.fillRect(0, y, Constants.SCREEN_WIDTH, height);
    }
    
    /**
     * Draws wave information
     * @param g Graphics context
     */
    private void drawWaveInfo(Graphics2D g) {
        int alpha = 255 - 255 * waveDelay / 180; // Fade in
        if (alpha > 255) alpha = 255;
        if (alpha < 0) alpha = 0;
        
        Color neonPurple = new Color(155, 135, 245, alpha);
        g.setColor(neonPurple);
        g.setFont(new Font("OCR A Extended", Font.BOLD, 36));
        
        String waveText = "WAVE " + currentWave;
        int textWidth = g.getFontMetrics().stringWidth(waveText);
        g.drawString(waveText, Constants.SCREEN_WIDTH / 2 - textWidth / 2, Constants.SCREEN_HEIGHT / 2);
    }
    
    /**
     * Returns the current score
     * @return The score
     */
    public int getScore() {
        return score;
    }
    
    /**
     * Returns the current wave
     * @return The wave number
     */
    public int getCurrentWave() {
        return currentWave;
    }
}
