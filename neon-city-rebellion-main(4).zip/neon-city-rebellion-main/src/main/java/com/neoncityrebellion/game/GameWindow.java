
package com.neoncityrebellion.game;

import com.neoncityrebellion.game.states.GameStateManager;
import com.neoncityrebellion.utils.Constants;

import javax.swing.*;
import java.awt.*;

/**
 * Main game window that contains the game panel.
 * Sets up the JFrame and initializes the game.
 */
public class GameWindow extends JFrame {
    
    public GameWindow() {
        this.setTitle("Neon City Rebellion");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        
        // Create and add the game panel
        GamePanel gamePanel = new GamePanel();
        this.add(gamePanel);
        
        // Pack and center the window
        this.pack();
        this.setLocationRelativeTo(null);
        
        // Start the game thread
        gamePanel.startGameThread();
    }
}
