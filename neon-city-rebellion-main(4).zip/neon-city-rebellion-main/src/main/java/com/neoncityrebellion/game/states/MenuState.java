
package com.neoncityrebellion.game.states;

import com.neoncityrebellion.input.KeyHandler;
import com.neoncityrebellion.utils.Constants;
import com.neoncityrebellion.utils.AssetManager;

import java.awt.*;

/**
 * Menu state of the game.
 */
public class MenuState extends GameState {
    
    private final String[] options = {"Play", "Controls", "Quit"};
    private int currentOption = 0;
    
    // Colors for cyberpunk theme
    private final Color neonPurple = new Color(155, 135, 245);
    private final Color neonBlue = new Color(14, 165, 233);
    private final Color neonPink = new Color(236, 72, 153);
    
    public MenuState(GameStateManager gsm) {
        super(gsm);
    }
    
    @Override
    public void init() {
        // Load any menu-specific resources
        AssetManager.loadMenuAssets();
    }
    
    @Override
    public void update(KeyHandler keyHandler) {
        // Navigate menu options
        if (keyHandler.upPressed) {
            keyHandler.upPressed = false;
            currentOption--;
            if (currentOption < 0) {
                currentOption = options.length - 1;
            }
            AssetManager.playSound("menu_select.wav");
        }
        
        if (keyHandler.downPressed) {
            keyHandler.downPressed = false;
            currentOption++;
            if (currentOption >= options.length) {
                currentOption = 0;
            }
            AssetManager.playSound("menu_select.wav");
        }
        
        // Select option
        if (keyHandler.enterPressed) {
            keyHandler.enterPressed = false;
            selectOption();
            AssetManager.playSound("menu_confirm.wav");
        }
    }
    
    private void selectOption() {
        switch (currentOption) {
            case 0 -> gsm.setState(Constants.PLAY_STATE);
            case 1 -> {
                // Show controls (could transition to a controls state)
            }
            case 2 -> System.exit(0);
        }
    }
    
    @Override
    public void render(Graphics2D g) {
        // Draw cyberpunk background
        drawCyberpunkBackground(g);
        
        // Draw game title
        g.setFont(new Font("OCR A Extended", Font.BOLD, 48));
        g.setColor(neonPurple);
        String title = "NEON CITY REBELLION";
        int titleWidth = g.getFontMetrics().stringWidth(title);
        g.drawString(title, Constants.SCREEN_WIDTH / 2 - titleWidth / 2, 150);
        
        // Draw cyberpunk subtitle
        g.setFont(new Font("OCR A Extended", Font.PLAIN, 24));
        g.setColor(neonBlue);
        String subtitle = "DEFEND THE FUTURE";
        int subtitleWidth = g.getFontMetrics().stringWidth(subtitle);
        g.drawString(subtitle, Constants.SCREEN_WIDTH / 2 - subtitleWidth / 2, 190);
        
        // Draw menu options
        g.setFont(new Font("OCR A Extended", Font.PLAIN, 24));
        for (int i = 0; i < options.length; i++) {
            if (i == currentOption) {
                g.setColor(neonPurple);
                // Draw selection indicator
                g.fillRect(Constants.SCREEN_WIDTH / 2 - 150, 280 + i * 50 - 20, 10, 30);
            } else {
                g.setColor(Color.WHITE);
            }
            g.drawString(options[i], Constants.SCREEN_WIDTH / 2 - 100, 280 + i * 50);
        }
        
        // Draw footer
        g.setFont(new Font("OCR A Extended", Font.PLAIN, 14));
        g.setColor(neonPink);
        String footer = "© 2025 NEON CITY STUDIOS";
        int footerWidth = g.getFontMetrics().stringWidth(footer);
        g.drawString(footer, Constants.SCREEN_WIDTH / 2 - footerWidth / 2, Constants.SCREEN_HEIGHT - 30);
    }
    
    /**
     * Draws a cyberpunk grid background
     * @param g Graphics context
     */
    private void drawCyberpunkBackground(Graphics2D g) {
        // Black background
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT);
        
        // Draw grid
        g.setColor(new Color(neonPurple.getRed(), neonPurple.getGreen(), neonPurple.getBlue(), 40));
        
        // Horizontal lines
        for (int y = 0; y < Constants.SCREEN_HEIGHT; y += 30) {
            g.drawLine(0, y, Constants.SCREEN_WIDTH, y);
        }
        
        // Vertical lines
        for (int x = 0; x < Constants.SCREEN_WIDTH; x += 30) {
            g.drawLine(x, 0, x, Constants.SCREEN_HEIGHT);
        }
    }
}
