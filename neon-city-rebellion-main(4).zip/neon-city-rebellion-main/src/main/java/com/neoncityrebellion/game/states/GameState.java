
package com.neoncityrebellion.game.states;

import com.neoncityrebellion.input.KeyHandler;

import java.awt.Graphics2D;

/**
 * Abstract class for game states.
 */
public abstract class GameState {
    
    protected GameStateManager gsm;
    
    public GameState(GameStateManager gsm) {
        this.gsm = gsm;
        init();
    }
    
    /**
     * Initialize the state
     */
    public abstract void init();
    
    /**
     * Update the state
     * @param keyHandler The key handler for input
     */
    public abstract void update(KeyHandler keyHandler);
    
    /**
     * Render the state
     * @param g The graphics object
     */
    public abstract void render(Graphics2D g);
}
