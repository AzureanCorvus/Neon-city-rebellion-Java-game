
package com.neoncityrebellion.game.states;

import com.neoncityrebellion.input.KeyHandler;
import com.neoncityrebellion.utils.Constants;

import java.awt.Graphics2D;

/**
 * Manages different game states (menu, gameplay, game over).
 */
public class GameStateManager {
    
    // Array of game states
    private final GameState[] gameStates;
    private int currentState;
    
    // Game states
    private static final int NUM_STATES = 3;
    private static final int MENU_STATE = Constants.MENU_STATE;
    private static final int PLAY_STATE = Constants.PLAY_STATE;
    private static final int GAME_OVER_STATE = Constants.GAME_OVER_STATE;
    
    public GameStateManager() {
        gameStates = new GameState[NUM_STATES];
        currentState = MENU_STATE;
        loadState(currentState);
    }
    
    /**
     * Loads a game state
     * @param state The state to load
     */
    private void loadState(int state) {
        if (state == MENU_STATE) {
            gameStates[state] = new MenuState(this);
        } else if (state == PLAY_STATE) {
            gameStates[state] = new PlayState(this);
        } else if (state == GAME_OVER_STATE) {
            gameStates[state] = new GameOverState(this);
        }
    }
    
    /**
     * Unloads a game state
     * @param state The state to unload
     */
    private void unloadState(int state) {
        gameStates[state] = null;
    }
    
    /**
     * Sets the current game state
     * @param state The state to set
     */
    public void setState(int state) {
        unloadState(currentState);
        currentState = state;
        loadState(currentState);
    }
    
    /**
     * Updates the current game state
     * @param keyHandler The key handler for input
     */
    public void update(KeyHandler keyHandler) {
        if (gameStates[currentState] != null) {
            gameStates[currentState].update(keyHandler);
        }
    }
    
    /**
     * Renders the current game state
     * @param g The graphics object
     */
    public void render(Graphics2D g) {
        if (gameStates[currentState] != null) {
            gameStates[currentState].render(g);
        }
    }
}
