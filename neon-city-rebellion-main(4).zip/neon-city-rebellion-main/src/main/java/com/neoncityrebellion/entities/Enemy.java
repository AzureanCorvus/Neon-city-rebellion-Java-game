
package com.neoncityrebellion.entities;

import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Random;

/**
 * Abstract class for all enemy types.
 */
public abstract class Enemy extends Entity {
    
    // Enemy attributes
    protected int health;
    protected int maxHealth;
    protected int damage;
    protected int scoreValue;
    protected int shootingCooldown;
    protected int currentCooldown;
    protected Random random = new Random();
    
    /**
     * Constructor for Enemy
     * @param x X position
     * @param y Y position
     * @param width Width of enemy
     * @param height Height of enemy
     * @param health Health points
     * @param damage Damage dealt
     * @param scoreValue Score value when destroyed
     */
    public Enemy(int x, int y, int width, int height, int health, int damage, int scoreValue) {
        super(x, y, width, height);
        this.health = health;
        this.maxHealth = health;
        this.damage = damage;
        this.scoreValue = scoreValue;
        this.shootingCooldown = 60 + random.nextInt(60); // 1-2 seconds at 60 FPS
        this.currentCooldown = random.nextInt(shootingCooldown); // Randomize initial cooldown
    }
    
    /**
     * Updates the enemy
     * @param player The player to track
     * @param bullets The bullets list for enemy bullets
     */
    public abstract void update(Player player, ArrayList<Bullet> bullets);
    
    @Override
    public abstract void update();
    
    @Override
    public abstract void render(Graphics2D g);
    
    /**
     * Enemy takes damage
     * @param damage Amount of damage to take
     */
    public void takeDamage(int damage) {
        health -= damage;
        if (health < 0) {
            health = 0;
        }
    }
    
    // Getters
    public int getHealth() { return health; }
    
    public int getMaxHealth() { return maxHealth; }
    
    public int getDamage() { return damage; }
    
    public int getScoreValue() { return scoreValue; }
}
