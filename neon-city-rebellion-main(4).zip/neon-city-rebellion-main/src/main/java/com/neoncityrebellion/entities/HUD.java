
package com.neoncityrebellion.entities;

import com.neoncityrebellion.utils.Constants;

import java.awt.*;

/**
 * Heads-up display for showing game information.
 */
public class HUD {
    
    private final Player player;
    private int animationFrame = 0;
    
    // Colors
    private final Color neonPurple = new Color(155, 135, 245);
    private final Color neonGreen = new Color(16, 185, 129);
    private final Color neonBlue = new Color(14, 165, 233);
    private final Color neonRed = new Color(239, 68, 68);
    
    /**
     * Constructor for HUD
     * @param player The player to display information for
     */
    public HUD(Player player) {
        this.player = player;
    }
    
    /**
     * Updates the HUD
     */
    public void update() {
        animationFrame++;
    }
    
    /**
     * Renders the HUD
     * @param g Graphics context
     */
    public void render(Graphics2D g) {
        // Draw health bar
        drawHealthBar(g);
        
        // Draw weapon info
        drawWeaponInfo(g);
        
        // Draw shield info if active
        if (player.hasShield()) {
            drawShieldInfo(g);
        }
    }
    
    /**
     * Draws the health bar
     * @param g Graphics context
     */
    private void drawHealthBar(Graphics2D g) {
        int barWidth = 200;
        int barHeight = 20;
        int barX = 20;
        int barY = Constants.SCREEN_HEIGHT - 30;
        
        // Draw background
        g.setColor(new Color(0, 0, 0, 150));
        g.fillRect(barX - 5, barY - 5, barWidth + 10, barHeight + 10);
        
        // Draw border
        g.setColor(neonPurple);
        g.drawRect(barX - 5, barY - 5, barWidth + 10, barHeight + 10);
        
        // Draw health bar background
        g.setColor(Color.DARK_GRAY);
        g.fillRect(barX, barY, barWidth, barHeight);
        
        // Calculate health percentage
        float healthPercentage = (float) player.getHealth() / player.getMaxHealth();
        
        // Determine color based on health
        Color healthColor;
        if (healthPercentage > 0.66) {
            healthColor = neonGreen;
        } else if (healthPercentage > 0.33) {
            healthColor = neonBlue;
        } else {
            healthColor = neonRed;
        }
        
        // Draw health bar
        g.setColor(healthColor);
        g.fillRect(barX, barY, (int) (barWidth * healthPercentage), barHeight);
        
        // Draw health text
        g.setColor(Color.WHITE);
        g.setFont(new Font("OCR A Extended", Font.BOLD, 14));
        String healthText = "HEALTH: " + player.getHealth() + "/" + player.getMaxHealth();
        g.drawString(healthText, barX + 10, barY + 15);
    }
    
    /**
     * Draws the weapon information
     * @param g Graphics context
     */
    private void drawWeaponInfo(Graphics2D g) {
        int boxWidth = 150;
        int boxHeight = 60;
        int boxX = Constants.SCREEN_WIDTH - boxWidth - 20;
        int boxY = Constants.SCREEN_HEIGHT - boxHeight - 20;
        
        // Draw background
        g.setColor(new Color(0, 0, 0, 150));
        g.fillRect(boxX, boxY, boxWidth, boxHeight);
        
        // Draw border
        g.setColor(neonPurple);
        g.drawRect(boxX, boxY, boxWidth, boxHeight);
        
        // Draw weapon type
        g.setFont(new Font("OCR A Extended", Font.BOLD, 14));
        g.setColor(Color.WHITE);
        
        String weaponName;
        Color weaponColor;
        
        switch (player.getWeaponType()) {
            case 1 -> {
                weaponName = "RAPID FIRE";
                weaponColor = neonBlue;
            }
            case 2 -> {
                weaponName = "SPREAD SHOT";
                weaponColor = neonRed;
            }
            default -> {
                weaponName = "STANDARD";
                weaponColor = neonGreen;
            }
        }
        
        g.drawString("WEAPON: ", boxX + 10, boxY + 20);
        g.setColor(weaponColor);
        g.drawString(weaponName, boxX + 10, boxY + 40);
        
        // Draw timer if weapon upgrade is active
        if (player.getWeaponType() > 0 && player.getWeaponTimer() > 0) {
            g.setColor(Color.WHITE);
            String timerText = "TIME: " + (player.getWeaponTimer() / 60) + "s";
            g.drawString(timerText, boxX + 10, boxY + 55);
        }
    }
    
    /**
     * Draws the shield information
     * @param g Graphics context
     */
    private void drawShieldInfo(Graphics2D g) {
        // Only draw if shield is active
        if (player.hasShield() && player.getShieldTimer() > 0) {
            int boxWidth = 150;
            int boxHeight = 40;
            int boxX = Constants.SCREEN_WIDTH - boxWidth - 20;
            int boxY = Constants.SCREEN_HEIGHT - 140;
            
            // Draw background
            g.setColor(new Color(0, 0, 0, 150));
            g.fillRect(boxX, boxY, boxWidth, boxHeight);
            
            // Calculate pulse effect
            int pulse = (int) (Math.sin(animationFrame * 0.2) * 2);
            
            // Draw border with pulse effect
            g.setColor(neonBlue);
            g.drawRect(boxX - pulse, boxY - pulse, boxWidth + pulse * 2, boxHeight + pulse * 2);
            
            // Draw shield text
            g.setFont(new Font("OCR A Extended", Font.BOLD, 14));
            g.setColor(Color.WHITE);
            g.drawString("SHIELD: ACTIVE", boxX + 10, boxY + 20);
            
            // Draw timer
            String timerText = "TIME: " + (player.getShieldTimer() / 60) + "s";
            g.drawString(timerText, boxX + 10, boxY + 35);
        }
    }
}
