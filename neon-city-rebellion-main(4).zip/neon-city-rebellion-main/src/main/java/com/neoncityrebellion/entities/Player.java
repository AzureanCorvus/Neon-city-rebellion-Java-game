package com.neoncityrebellion.entities;

import com.neoncityrebellion.input.KeyHandler;
import com.neoncityrebellion.utils.AssetManager;
import com.neoncityrebellion.utils.Constants;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

/**
 * Player entity controlled by the user.
 */
public class Player extends Entity {
    
    // Player attributes
    private int health;
    private int maxHealth;
    private int shootingCooldown;
    private int currentCooldown;
    private int weaponType; // 0 = normal, 1 = rapid, 2 = spread
    private int weaponTimer; // Timer for temporary weapon upgrades
    private boolean hasShield;
    private int shieldTimer;
    
    // Player sprite and animation
    private BufferedImage[] sprites;
    private int currentSprite;
    private int animationTimer;
    
    // Engine effect
    private int engineAnimationTimer;
    
    // Shield effect
    private int shieldPulseTimer;
    
    /**
     * Constructor for Player
     * @param x X position
     * @param y Y position
     * @param width Width of player
     * @param height Height of player
     */
    public Player(int x, int y, int width, int height) {
        super(x, y, width, height);
        
        // Initialize player attributes
        health = Constants.PLAYER_MAX_HEALTH;
        maxHealth = Constants.PLAYER_MAX_HEALTH;
        shootingCooldown = Constants.SHOOTING_COOLDOWN;
        currentCooldown = 0;
        weaponType = 0;
        weaponTimer = 0;
        hasShield = false;
        shieldTimer = 0;
        
        // Load sprites
        sprites = AssetManager.getPlayerSprites();
        currentSprite = 0;
        animationTimer = 0;
        engineAnimationTimer = 0;
        shieldPulseTimer = 0;
    }
    
    /**
     * Updates the player
     * @param keyHandler The key handler for input
     * @param bullets The bullets list to add new bullets to
     */
    public void update(KeyHandler keyHandler, ArrayList<Bullet> bullets) {
        // Handle movement
        handleMovement(keyHandler);
        
        // Handle shooting
        handleShooting(keyHandler, bullets);
        
        // Update weapon timer
        if (weaponTimer > 0) {
            weaponTimer--;
            
            if (weaponTimer <= 0) {
                weaponType = 0; // Revert to normal weapon
            }
        }
        
        // Update shield timer
        if (shieldTimer > 0) {
            shieldTimer--;
            
            if (shieldTimer <= 0) {
                hasShield = false;
            }
        }
        
        // Update animation
        updateAnimation();
    }
    
    /**
     * Handles player movement based on input
     * @param keyHandler The key handler for input
     */
    private void handleMovement(KeyHandler keyHandler) {
        // Reset velocity
        velocityX = 0;
        velocityY = 0;
        
        // Update velocity based on input
        if (keyHandler.leftPressed) {
            velocityX = -Constants.PLAYER_SPEED;
        }
        
        if (keyHandler.rightPressed) {
            velocityX = Constants.PLAYER_SPEED;
        }
        
        if (keyHandler.upPressed) {
            velocityY = -Constants.PLAYER_SPEED;
        }
        
        if (keyHandler.downPressed) {
            velocityY = Constants.PLAYER_SPEED;
        }
        
        // Update position
        x += velocityX;
        y += velocityY;
        
        // Keep player within screen bounds
        if (x < 0) {
            x = 0;
        } else if (x > Constants.SCREEN_WIDTH - width) {
            x = Constants.SCREEN_WIDTH - width;
        }
        
        if (y < 0) {
            y = 0;
        } else if (y > Constants.SCREEN_HEIGHT - height) {
            y = Constants.SCREEN_HEIGHT - height;
        }
    }
    
    /**
     * Handles player shooting based on input
     * @param keyHandler The key handler for input
     * @param bullets The bullets list to add new bullets to
     */
    private void handleShooting(KeyHandler keyHandler, ArrayList<Bullet> bullets) {
        // Decrease cooldown
        if (currentCooldown > 0) {
            currentCooldown--;
        }
        
        // Check if player is shooting
        if (keyHandler.spacePressed && currentCooldown <= 0) {
            // Reset cooldown
            currentCooldown = weaponType == 1 ? shootingCooldown / 2 : shootingCooldown;
            
            // Create bullet based on weapon type
            switch (weaponType) {
                case 0 -> { // Normal weapon
                    bullets.add(new Bullet(x + width / 2 - Constants.BULLET_WIDTH / 2, 
                                          y - Constants.BULLET_HEIGHT,
                                          Constants.BULLET_WIDTH, Constants.BULLET_HEIGHT,
                                          0, -Constants.BULLET_SPEED, 10, true));
                }
                case 1 -> { // Rapid fire weapon (handled by cooldown reduction)
                    bullets.add(new Bullet(x + width / 2 - Constants.BULLET_WIDTH / 2,
                                          y - Constants.BULLET_HEIGHT, 
                                          Constants.BULLET_WIDTH, Constants.BULLET_HEIGHT,
                                          0, -Constants.BULLET_SPEED, 10, true));
                }
                case 2 -> { // Spread weapon
                    // Center bullet
                    bullets.add(new Bullet(x + width / 2 - Constants.BULLET_WIDTH / 2,
                                          y - Constants.BULLET_HEIGHT,
                                          Constants.BULLET_WIDTH, Constants.BULLET_HEIGHT,
                                          0, -Constants.BULLET_SPEED, 10, true));
                    
                    // Left bullet
                    bullets.add(new Bullet(x + width / 2 - Constants.BULLET_WIDTH / 2,
                                          y - Constants.BULLET_HEIGHT,
                                          Constants.BULLET_WIDTH, Constants.BULLET_HEIGHT,
                                          -1, -Constants.BULLET_SPEED, 10, true));
                    
                    // Right bullet
                    bullets.add(new Bullet(x + width / 2 - Constants.BULLET_WIDTH / 2,
                                          y - Constants.BULLET_HEIGHT,
                                          Constants.BULLET_WIDTH, Constants.BULLET_HEIGHT,
                                          1, -Constants.BULLET_SPEED, 10, true));
                }
            }
            
            AssetManager.playSound("player_shoot.wav");
        }
    }
    
    /**
     * Updates player animation
     */
    private void updateAnimation() {
        // Update ship animation
        animationTimer++;
        if (animationTimer >= 10) {
            animationTimer = 0;
            currentSprite = (currentSprite + 1) % sprites.length;
        }
        
        // Update engine animation
        engineAnimationTimer++;
        
        // Update shield pulse animation
        if (hasShield) {
            shieldPulseTimer++;
        }
    }
    
    @Override
    public void update() {
        // This method is unused, player update is handled by the overloaded method
    }
    
    @Override
    public void render(Graphics2D g) {
        // Draw player sprite
        if (sprites != null && sprites.length > 0 && sprites[currentSprite] != null) {
            g.drawImage(sprites[currentSprite], x, y, width, height, null);
        } else {
            // Fallback if sprite is not loaded
            g.setColor(Color.CYAN);
            g.fillRect(x, y, width, height);
        }
        
        // Draw engine effect
        drawEngineEffect(g);
        
        // Draw shield if active
        if (hasShield) {
            drawShield(g);
        }
    }
    
    /**
     * Draws the engine effect
     * @param g Graphics context
     */
    private void drawEngineEffect(Graphics2D g) {
        int engineWidth = width / 3;
        int engineHeight = height / 4;
        int engineX = x + width / 2 - engineWidth / 2;
        int engineY = y + height;
        
        // Create a flame-like effect that animates
        int flameHeight = engineHeight + (int) (Math.sin(engineAnimationTimer * 0.2) * 5);
        
        // Draw main engine flame
        Color engineColor = new Color(255, 100, 0, 200); // Orange with alpha
        g.setColor(engineColor);
        
        // Create a polygon for the flame shape
        int[] xPoints = {engineX, engineX + engineWidth, engineX + engineWidth / 2};
        int[] yPoints = {engineY, engineY, engineY + flameHeight};
        g.fillPolygon(xPoints, yPoints, 3);
        
        // Draw inner flame (brighter)
        int innerWidth = engineWidth / 2;
        int innerX = x + width / 2 - innerWidth / 2;
        
        Color innerColor = new Color(255, 200, 0, 180); // Brighter orange
        g.setColor(innerColor);
        
        int[] innerXPoints = {innerX, innerX + innerWidth, innerX + innerWidth / 2};
        int[] innerYPoints = {engineY, engineY, engineY + flameHeight / 2};
        g.fillPolygon(innerXPoints, innerYPoints, 3);
    }
    
    /**
     * Draws the shield effect
     * @param g Graphics context
     */
    private void drawShield(Graphics2D g) {
        // Calculate shield pulse effect
        int pulse = (int) (Math.sin(shieldPulseTimer * 0.1) * 5);
        int shieldSize = width + pulse;
        
        // Draw shield circle
        Color shieldColor = new Color(0, 150, 255, 100); // Blue with alpha
        g.setColor(shieldColor);
        g.drawOval(x + width / 2 - shieldSize / 2, 
                  y + height / 2 - shieldSize / 2, 
                  shieldSize, shieldSize);
        
        // Draw another circle for effect
        shieldColor = new Color(0, 200, 255, 50); // Lighter blue with less alpha
        g.setColor(shieldColor);
        g.drawOval(x + width / 2 - (shieldSize + 5) / 2, 
                  y + height / 2 - (shieldSize + 5) / 2, 
                  shieldSize + 5, shieldSize + 5);
    }
    
    /**
     * Player takes damage
     * @param damage Amount of damage to take
     */
    public void takeDamage(int damage) {
        if (hasShield) {
            // Shield absorbs damage
            return;
        }
        
        health -= damage;
        if (health < 0) {
            health = 0;
        }
    }
    
    /**
     * Heal the player
     * @param amount Amount to heal
     */
    public void heal(int amount) {
        health += amount;
        if (health > maxHealth) {
            health = maxHealth;
        }
    }
    
    /**
     * Set weapon upgrade
     * @param type Weapon type (0=normal, 1=rapid, 2=spread)
     * @param duration Duration in frames
     */
    public void setWeaponUpgrade(int type, int duration) {
        weaponType = type;
        weaponTimer = duration;
    }
    
    /**
     * Activate shield
     * @param duration Duration in frames
     */
    public void activateShield(int duration) {
        hasShield = true;
        shieldTimer = duration;
    }
    
    // Getters
    public int getHealth() { return health; }
    
    public int getMaxHealth() { return maxHealth; }
    
    public int getWeaponType() { return weaponType; }
    
    public boolean hasShield() { return hasShield; }
    
    public int getShieldTimer() { return shieldTimer; }
    
    public int getWeaponTimer() { return weaponTimer; }
}
