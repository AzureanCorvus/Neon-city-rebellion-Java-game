
package com.neoncityrebellion.entities;

import com.neoncityrebellion.utils.AssetManager;

import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * Health power-up that restores player health.
 */
public class HealthPowerUp extends PowerUp {
    
    private BufferedImage sprite;
    
    /**
     * Constructor for HealthPowerUp
     * @param x X position
     * @param y Y position
     * @param width Width of power-up
     * @param height Height of power-up
     */
    public HealthPowerUp(int x, int y, int width, int height) {
        super(x, y, width, height, 30, 0); // 30 health points, instantaneous effect
        sprite = AssetManager.getPowerUpSprite(0); // Health sprite
    }
    
    @Override
    public void applyEffect(Player player) {
        player.heal(effectValue);
    }
    
    @Override
    public void render(Graphics2D g) {
        // Draw sprite
        if (sprite != null) {
            g.drawImage(sprite, x, y, width, height, null);
        } else {
            // Fallback if sprite is not loaded
            g.setColor(Color.GREEN);
            g.fillOval(x, y, width, height);
            
            // Draw plus symbol
            g.setColor(Color.WHITE);
            g.fillRect(x + width / 3, y + height / 2 - 2, width / 3, 4);
            g.fillRect(x + width / 2 - 2, y + height / 3, 4, height / 3);
        }
        
        // Draw glow effect
        drawGlowEffect(g);
    }
    
    /**
     * Draws glow effect
     * @param g Graphics context
     */
    private void drawGlowEffect(Graphics2D g) {
        // Calculate pulse effect
        int pulse = (int) (Math.sin(animationFrame * 0.2) * 3);
        
        // Draw glow
        g.setColor(new Color(0, 255, 0, 100)); // Semi-transparent green
        g.drawOval(x - pulse, y - pulse, width + pulse * 2, height + pulse * 2);
    }
}
