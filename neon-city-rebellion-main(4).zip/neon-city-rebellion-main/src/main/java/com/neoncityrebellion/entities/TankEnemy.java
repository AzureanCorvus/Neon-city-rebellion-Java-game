package com.neoncityrebellion.entities;

import com.neoncityrebellion.utils.AssetManager;
import com.neoncityrebellion.utils.Constants;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

/**
 * Tank enemy type - slower but has more health and shoots more.
 */
public class TankEnemy extends Enemy {
    
    private BufferedImage sprite;
    private int attackPattern; // 0 = single shot, 1 = double shot, 2 = spread shot
    private int pulseEffect;
    
    /**
     * Constructor for TankEnemy
     * @param x X position
     * @param y Y position
     * @param width Width of enemy
     * @param height Height of enemy
     */
    public TankEnemy(int x, int y, int width, int height) {
        super(x, y, width, height, 
             Constants.TANK_ENEMY_HEALTH,
             15,
             Constants.TANK_ENEMY_SCORE);
        
        velocityY = Constants.TANK_ENEMY_SPEED;
        sprite = AssetManager.getEnemySprite(2);
        attackPattern = random.nextInt(3);
        pulseEffect = 0;
    }
    
    @Override
    public void update(Player player, ArrayList<Bullet> bullets) {
        // Update position (slower than other enemies)
        y += velocityY;
        
        // Move slightly toward player on X-axis
        if (player.getX() + player.getWidth() / 2 < x + width / 2) {
            x -= 1;
        } else if (player.getX() + player.getWidth() / 2 > x + width / 2) {
            x += 1;
        }
        
        // Keep enemy within screen bounds
        if (x < 0) {
            x = 0;
        } else if (x > Constants.SCREEN_WIDTH - width) {
            x = Constants.SCREEN_WIDTH - width;
        }
        
        // Shooting logic
        if (currentCooldown > 0) {
            currentCooldown--;
        } else {
            // Reset cooldown (shorter than other enemies)
            currentCooldown = shootingCooldown / 2;
            
            // Different attack patterns
            switch (attackPattern) {
                case 0 -> { // Single powerful shot
                    bullets.add(new Bullet(x + width / 2 - Constants.BULLET_WIDTH / 2,
                                          y + height,
                                          Constants.BULLET_WIDTH, Constants.BULLET_HEIGHT,
                                          0, Constants.BULLET_SPEED / 2, damage, false));
                }
                case 1 -> { // Double shot
                    bullets.add(new Bullet(x + width / 4 - Constants.BULLET_WIDTH / 2,
                                          y + height,
                                          Constants.BULLET_WIDTH, Constants.BULLET_HEIGHT,
                                          0, Constants.BULLET_SPEED / 2, damage / 2, false));
                    
                    bullets.add(new Bullet(x + width * 3 / 4 - Constants.BULLET_WIDTH / 2,
                                          y + height,
                                          Constants.BULLET_WIDTH, Constants.BULLET_HEIGHT,
                                          0, Constants.BULLET_SPEED / 2, damage / 2, false));
                }
                case 2 -> { // Spread shot
                    bullets.add(new Bullet(x + width / 2 - Constants.BULLET_WIDTH / 2,
                                          y + height,
                                          Constants.BULLET_WIDTH, Constants.BULLET_HEIGHT,
                                          0, Constants.BULLET_SPEED / 2, damage / 3, false));
                    
                    bullets.add(new Bullet(x + width / 2 - Constants.BULLET_WIDTH / 2,
                                          y + height,
                                          Constants.BULLET_WIDTH, Constants.BULLET_HEIGHT,
                                          -1, Constants.BULLET_SPEED / 2, damage / 3, false));
                    
                    bullets.add(new Bullet(x + width / 2 - Constants.BULLET_WIDTH / 2,
                                          y + height,
                                          Constants.BULLET_WIDTH, Constants.BULLET_HEIGHT,
                                          1, Constants.BULLET_SPEED / 2, damage / 3, false));
                }
            }
        }
        
        // Update pulse effect
        pulseEffect++;
    }
    
    @Override
    public void update() {
        // This is handled by the overloaded method
    }
    
    @Override
    public void render(Graphics2D g) {
        // Draw enemy sprite
        if (sprite != null) {
            g.drawImage(sprite, x, y, width, height, null);
        } else {
            // Fallback if sprite is not loaded
            g.setColor(new Color(100, 0, 150)); // Purple
            g.fillRect(x, y, width, height);
        }
        
        // Draw health bar
        drawHealthBar(g);
        
        // Draw shield-like effect
        drawShieldEffect(g);
    }
    
    /**
     * Draws the enemy health bar
     * @param g Graphics context
     */
    private void drawHealthBar(Graphics2D g) {
        int barWidth = width;
        int barHeight = 5;
        int barX = x;
        int barY = y - barHeight - 2;
        
        // Background bar
        g.setColor(Color.GRAY);
        g.fillRect(barX, barY, barWidth, barHeight);
        
        // Health bar
        float healthPercentage = (float) health / maxHealth;
        g.setColor(new Color(100, 0, 150)); // Purple
        g.fillRect(barX, barY, (int) (barWidth * healthPercentage), barHeight);
    }
    
    /**
     * Draws shield-like effect
     * @param g Graphics context
     */
    private void drawShieldEffect(Graphics2D g) {
        // Pulsing shield effect
        int pulse = (int) (Math.sin(pulseEffect * 0.1) * 3);
        
        g.setColor(new Color(100, 0, 150, 50)); // Semi-transparent purple
        g.drawRect(x - pulse, y - pulse, width + pulse * 2, height + pulse * 2);
    }
}
