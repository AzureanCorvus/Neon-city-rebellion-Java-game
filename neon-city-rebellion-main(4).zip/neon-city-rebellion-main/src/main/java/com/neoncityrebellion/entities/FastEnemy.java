package com.neoncityrebellion.entities;

import com.neoncityrebellion.utils.AssetManager;
import com.neoncityrebellion.utils.Constants;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

/**
 * Fast enemy type - quicker movement but less health.
 */
public class FastEnemy extends Enemy {
    
    private BufferedImage sprite;
    private int moveDirection; // -1 left, 1 right
    private int changeDirectionCounter;
    
    /**
     * Constructor for FastEnemy
     * @param x X position
     * @param y Y position
     * @param width Width of enemy
     * @param height Height of enemy
     */
    public FastEnemy(int x, int y, int width, int height) {
        super(x, y, width, height, 
             Constants.FAST_ENEMY_HEALTH,
             5,
             Constants.FAST_ENEMY_SCORE);
        
        velocityY = Constants.FAST_ENEMY_SPEED;
        sprite = AssetManager.getEnemySprite(1);
        moveDirection = random.nextInt(2) * 2 - 1; // -1 or 1
        changeDirectionCounter = random.nextInt(60) + 30; // 0.5-1.5 seconds at 60 FPS
    }
    
    @Override
    public void update(Player player, ArrayList<Bullet> bullets) {
        // Update position
        y += velocityY;
        x += moveDirection * 2;
        
        // Change direction periodically
        changeDirectionCounter--;
        if (changeDirectionCounter <= 0) {
            moveDirection *= -1;
            changeDirectionCounter = random.nextInt(60) + 30;
        }
        
        // Keep enemy within screen bounds
        if (x < 0) {
            x = 0;
            moveDirection = 1;
        } else if (x > Constants.SCREEN_WIDTH - width) {
            x = Constants.SCREEN_WIDTH - width;
            moveDirection = -1;
        }
        
        // Shooting logic (fast enemies shoot less frequently)
        if (currentCooldown > 0) {
            currentCooldown--;
        } else {
            // Reset cooldown (longer than normal enemies)
            currentCooldown = shootingCooldown * 2;
            
            // Fast enemies occasionally shoot
            if (random.nextInt(100) < 30) { // 30% chance to shoot
                bullets.add(new Bullet(x + width / 2 - Constants.BULLET_WIDTH / 2,
                                      y + height,
                                      Constants.BULLET_WIDTH, Constants.BULLET_HEIGHT,
                                      0, Constants.BULLET_SPEED / 2, damage, false));
            }
        }
    }
    
    @Override
    public void update() {
        // This is handled by the overloaded method
    }
    
    @Override
    public void render(Graphics2D g) {
        // Draw enemy sprite
        if (sprite != null) {
            g.drawImage(sprite, x, y, width, height, null);
        } else {
            // Fallback if sprite is not loaded
            g.setColor(new Color(255, 100, 0)); // Orange
            g.fillRect(x, y, width, height);
        }
        
        // Draw health bar
        drawHealthBar(g);
        
        // Draw speed lines effect
        drawSpeedLines(g);
    }
    
    /**
     * Draws the enemy health bar
     * @param g Graphics context
     */
    private void drawHealthBar(Graphics2D g) {
        int barWidth = width;
        int barHeight = 5;
        int barX = x;
        int barY = y - barHeight - 2;
        
        // Background bar
        g.setColor(Color.GRAY);
        g.fillRect(barX, barY, barWidth, barHeight);
        
        // Health bar
        float healthPercentage = (float) health / maxHealth;
        g.setColor(new Color(255, 100, 0)); // Orange
        g.fillRect(barX, barY, (int) (barWidth * healthPercentage), barHeight);
    }
    
    /**
     * Draws speed lines effect
     * @param g Graphics context
     */
    private void drawSpeedLines(Graphics2D g) {
        g.setColor(new Color(255, 255, 255, 100)); // Semi-transparent white
        
        // Draw a few lines behind the enemy
        for (int i = 0; i < 3; i++) {
            int lineX = x + width / 2;
            int lineY = y + height / 4 + i * (height / 3);
            g.drawLine(lineX, lineY, lineX - moveDirection * 10, lineY);
        }
    }
}
