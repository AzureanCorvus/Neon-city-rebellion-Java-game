
package com.neoncityrebellion.entities;

import com.neoncityrebellion.utils.AssetManager;

import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * Bullet entity for player and enemy projectiles.
 */
public class Bullet extends Entity {
    
    private int damage;
    private boolean playerBullet;
    private BufferedImage sprite;
    private int animationFrame;
    
    /**
     * Constructor for Bullet
     * @param x X position
     * @param y Y position
     * @param width Width of bullet
     * @param height Height of bullet
     * @param velocityX X velocity
     * @param velocityY Y velocity
     * @param damage Damage amount
     * @param playerBullet Whether it's a player bullet
     */
    public Bullet(int x, int y, int width, int height, int velocityX, int velocityY, int damage, boolean playerBullet) {
        super(x, y, width, height);
        this.velocityX = velocityX;
        this.velocityY = velocityY;
        this.damage = damage;
        this.playerBullet = playerBullet;
        
        // Load bullet sprite based on type
        this.sprite = playerBullet ? AssetManager.getPlayerBulletSprite() : AssetManager.getEnemyBulletSprite();
        this.animationFrame = 0;
    }
    
    @Override
    public void update() {
        // Update position
        x += velocityX;
        y += velocityY;
        
        // Update animation frame
        animationFrame++;
    }
    
    @Override
    public void render(Graphics2D g) {
        // Draw bullet sprite
        if (sprite != null) {
            g.drawImage(sprite, x, y, width, height, null);
        } else {
            // Fallback if sprite is not loaded
            if (playerBullet) {
                g.setColor(Color.CYAN);
            } else {
                g.setColor(Color.RED);
            }
            g.fillOval(x, y, width, height);
        }
        
        // Draw bullet trail/glow effect
        drawBulletEffect(g);
    }
    
    /**
     * Draws bullet trail/glow effect
     * @param g Graphics context
     */
    private void drawBulletEffect(Graphics2D g) {
        // Determine color based on bullet type
        Color glowColor;
        if (playerBullet) {
            glowColor = new Color(0, 255, 255, 100); // Cyan with alpha
        } else {
            glowColor = new Color(255, 0, 0, 100); // Red with alpha
        }
        
        g.setColor(glowColor);
        
        // Draw trail
        int trailLength = 3;
        g.fillOval(x, y - (velocityY > 0 ? -trailLength : trailLength), 
                  width, height / 2);
        
        // Draw pulsing glow effect
        int pulse = (int) (Math.sin(animationFrame * 0.3) * 3);
        g.drawOval(x - pulse, y - pulse, width + pulse * 2, height + pulse * 2);
    }
    
    /**
     * Get the damage amount
     * @return Damage amount
     */
    public int getDamage() {
        return damage;
    }
    
    /**
     * Check if it's a player bullet
     * @return True if it's a player bullet
     */
    public boolean isPlayerBullet() {
        return playerBullet;
    }
}
