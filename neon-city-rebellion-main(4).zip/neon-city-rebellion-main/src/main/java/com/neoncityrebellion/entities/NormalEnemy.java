package com.neoncityrebellion.entities;

import com.neoncityrebellion.utils.AssetManager;
import com.neoncityrebellion.utils.Constants;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

/**
 * Normal enemy type - balanced stats and simple movement.
 */
public class NormalEnemy extends Enemy {
    
    private BufferedImage sprite;
    private int movePattern; // 0 = straight, 1 = sine wave, 2 = zigzag
    private double angle = 0; // For sine wave movement
    
    /**
     * Constructor for NormalEnemy
     * @param x X position
     * @param y Y position
     * @param width Width of enemy
     * @param height Height of enemy
     */
    public NormalEnemy(int x, int y, int width, int height) {
        super(x, y, width, height, 
             Constants.NORMAL_ENEMY_HEALTH,
             10,
             Constants.NORMAL_ENEMY_SCORE);
        
        velocityY = Constants.NORMAL_ENEMY_SPEED;
        sprite = AssetManager.getEnemySprite(0);
        movePattern = random.nextInt(3); // Random movement pattern
    }
    
    @Override
    public void update(Player player, ArrayList<Bullet> bullets) {
        // Update position based on movement pattern
        switch (movePattern) {
            case 0 -> { // Straight down
                y += velocityY;
            }
            case 1 -> { // Sine wave
                y += velocityY;
                angle += 0.05;
                x += Math.sin(angle) * 2;
            }
            case 2 -> { // Zigzag
                y += velocityY;
                if ((y / 30) % 2 == 0) {
                    x += 1;
                } else {
                    x -= 1;
                }
            }
        }
        
        // Keep enemy within screen bounds (x-axis only)
        if (x < 0) {
            x = 0;
            if (movePattern == 2) movePattern = 0; // Change pattern if hitting wall
        } else if (x > Constants.SCREEN_WIDTH - width) {
            x = Constants.SCREEN_WIDTH - width;
            if (movePattern == 2) movePattern = 0; // Change pattern if hitting wall
        }
        
        // Shooting logic
        if (currentCooldown > 0) {
            currentCooldown--;
        } else {
            // Reset cooldown
            currentCooldown = shootingCooldown;
            
            // Shoot if player is approximately below (within a range)
            if (Math.abs(player.getX() + player.getWidth() / 2 - (x + width / 2)) < 100) {
                bullets.add(new Bullet(x + width / 2 - Constants.BULLET_WIDTH / 2,
                                      y + height,
                                      Constants.BULLET_WIDTH, Constants.BULLET_HEIGHT,
                                      0, Constants.BULLET_SPEED / 2, damage, false));
            }
        }
    }
    
    @Override
    public void update() {
        // This is handled by the overloaded method
    }
    
    @Override
    public void render(Graphics2D g) {
        // Draw enemy sprite
        if (sprite != null) {
            g.drawImage(sprite, x, y, width, height, null);
        } else {
            // Fallback if sprite is not loaded
            g.setColor(Color.RED);
            g.fillRect(x, y, width, height);
        }
        
        // Draw health bar
        drawHealthBar(g);
    }
    
    /**
     * Draws the enemy health bar
     * @param g Graphics context
     */
    private void drawHealthBar(Graphics2D g) {
        int barWidth = width;
        int barHeight = 5;
        int barX = x;
        int barY = y - barHeight - 2;
        
        // Background bar
        g.setColor(Color.GRAY);
        g.fillRect(barX, barY, barWidth, barHeight);
        
        // Health bar
        float healthPercentage = (float) health / maxHealth;
        g.setColor(Color.RED);
        g.fillRect(barX, barY, (int) (barWidth * healthPercentage), barHeight);
    }
}
