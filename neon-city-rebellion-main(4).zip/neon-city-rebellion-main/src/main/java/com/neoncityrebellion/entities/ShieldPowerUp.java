
package com.neoncityrebellion.entities;

import com.neoncityrebellion.utils.AssetManager;

import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * Shield power-up that gives player temporary invincibility.
 */
public class ShieldPowerUp extends PowerUp {
    
    private BufferedImage sprite;
    
    /**
     * Constructor for ShieldPowerUp
     * @param x X position
     * @param y Y position
     * @param width Width of power-up
     * @param height Height of power-up
     */
    public ShieldPowerUp(int x, int y, int width, int height) {
        super(x, y, width, height, 0, 300); // 5 seconds at 60 FPS
        sprite = AssetManager.getPowerUpSprite(2); // Shield sprite
    }
    
    @Override
    public void applyEffect(Player player) {
        player.activateShield(effectDuration);
    }
    
    @Override
    public void render(Graphics2D g) {
        // Draw sprite
        if (sprite != null) {
            g.drawImage(sprite, x, y, width, height, null);
        } else {
            // Fallback if sprite is not loaded
            g.setColor(Color.BLUE);
            g.fillOval(x, y, width, height);
            
            // Draw shield symbol
            g.setColor(Color.WHITE);
            g.fillOval(x + width / 4, y + height / 4, width / 2, height / 2);
            g.setColor(Color.BLUE);
            g.fillOval(x + width / 3, y + height / 3, width / 3, height / 3);
        }
        
        // Draw glow effect
        drawGlowEffect(g);
    }
    
    /**
     * Draws glow effect
     * @param g Graphics context
     */
    private void drawGlowEffect(Graphics2D g) {
        // Calculate pulse effect
        int pulse = (int) (Math.sin(animationFrame * 0.2) * 3);
        
        // Draw glow
        g.setColor(new Color(0, 0, 255, 100)); // Semi-transparent blue
        g.drawOval(x - pulse, y - pulse, width + pulse * 2, height + pulse * 2);
    }
}
