
package com.neoncityrebellion.entities;

import java.awt.Graphics2D;
import java.awt.Rectangle;

/**
 * Base class for all game entities.
 */
public abstract class Entity {
    
    // Position and dimensions
    protected int x, y;
    protected int width, height;
    protected int velocityX, velocityY;
    
    // Status
    protected boolean active = true;
    
    /**
     * Constructor for Entity
     * @param x X position
     * @param y Y position
     * @param width Width of entity
     * @param height Height of entity
     */
    public Entity(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
    
    /**
     * Updates the entity
     */
    public abstract void update();
    
    /**
     * Renders the entity
     * @param g Graphics context
     */
    public abstract void render(Graphics2D g);
    
    /**
     * Returns the entity's collision box
     * @return Rectangle for collision detection
     */
    public Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }
    
    // Getters and setters
    public int getX() { return x; }
    
    public void setX(int x) { this.x = x; }
    
    public int getY() { return y; }
    
    public void setY(int y) { this.y = y; }
    
    public int getWidth() { return width; }
    
    public int getHeight() { return height; }
    
    public boolean isActive() { return active; }
    
    public void setActive(boolean active) { this.active = active; }
}
