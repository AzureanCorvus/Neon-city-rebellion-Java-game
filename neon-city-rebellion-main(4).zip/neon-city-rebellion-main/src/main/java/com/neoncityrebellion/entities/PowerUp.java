
package com.neoncityrebellion.entities;

import java.awt.Graphics2D;

/**
 * Abstract class for all power-up types.
 */
public abstract class PowerUp extends Entity {
    
    // Power-up attributes
    protected int effectValue;
    protected int effectDuration;
    protected int velocityY = 2; // Default downward speed
    protected int animationFrame = 0;
    
    /**
     * Constructor for PowerUp
     * @param x X position
     * @param y Y position
     * @param width Width of power-up
     * @param height Height of power-up
     * @param effectValue Value of the effect
     * @param effectDuration Duration of the effect in frames
     */
    public PowerUp(int x, int y, int width, int height, int effectValue, int effectDuration) {
        super(x, y, width, height);
        this.effectValue = effectValue;
        this.effectDuration = effectDuration;
    }
    
    @Override
    public void update() {
        // Update position
        y += velocityY;
        
        // Update animation frame
        animationFrame++;
    }
    
    /**
     * Apply the power-up effect to the player
     * @param player The player to apply the effect to
     */
    public abstract void applyEffect(Player player);
    
    // Getters
    public int getEffectValue() { return effectValue; }
    
    public int getEffectDuration() { return effectDuration; }
}
