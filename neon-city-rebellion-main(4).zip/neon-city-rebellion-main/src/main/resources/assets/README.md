
# Assets Directory

Place game assets in the appropriate subdirectories:

## Images
Place sprite images in the `images` directory:
- Player sprites (player_1.png, player_2.png)
- Enemy sprites (enemy_normal.png, enemy_fast.png, enemy_tank.png)
- Bullet sprites (player_bullet.png, enemy_bullet.png)
- Power-up sprites (powerup_health.png, powerup_rapid.png, powerup_shield.png)

## Sounds
Place sound effects in the `sounds` directory:
- Menu sounds (menu_select.wav, menu_confirm.wav)
- Game sounds (player_shoot.wav, enemy_shoot.wav, player_hit.wav, hit.wav, 
  enemy_explosion.wav, powerup.wav, wave_start.wav, game_over.wav)

## Music
Place background music in the `music` directory:
- Game music (game_music.wav)

Note: Alternatively, you can create your own asset files with these names or modify
the AssetManager to load your custom assets with different names.
