
import React from 'react';
import { BulletEntity } from '../GameContainer';

interface BulletProps {
  bullet: BulletEntity;
}

export const Bullet: React.FC<BulletProps> = ({ bullet }) => {
  // Different styles based on bullet type (player vs enemy)
  const bulletColor = bullet.isPlayerBullet ? '#9b87f5' : '#ef4444';
  const glowColor = bullet.isPlayerBullet ? 'rgba(155, 135, 245, 0.7)' : 'rgba(239, 68, 68, 0.7)';
  
  return (
    <div 
      className="absolute z-5"
      style={{
        left: `${bullet.x}px`,
        top: `${bullet.y}px`,
        width: `${bullet.width}px`,
        height: `${bullet.height}px`,
        backgroundColor: bulletColor,
        boxShadow: `0 0 5px ${glowColor}`,
        borderRadius: bullet.isPlayerBullet ? '0 50% 50% 0' : '50% 0 0 50%'
      }}
    ></div>
  );
};
