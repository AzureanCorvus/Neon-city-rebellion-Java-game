
import React from 'react';
import { GameEntity } from '../GameContainer';

interface PlayerProps {
  player: GameEntity;
}

export const Player: React.FC<PlayerProps> = ({ player }) => {
  // Player ship SVG 
  return (
    <div 
      className="absolute z-10 transition-transform"
      style={{
        left: `${player.x}px`,
        top: `${player.y}px`,
        width: `${player.width}px`,
        height: `${player.height}px`,
      }}
    >
      <svg 
        viewBox="0 0 100 120" 
        className="w-full h-full"
        style={{ filter: 'drop-shadow(0 0 5px rgba(155, 135, 245, 0.7))' }}
      >
        <polygon 
          points="30,60 10,40 10,80" 
          fill="#1A1F2C" 
          stroke="#9b87f5" 
          strokeWidth="2"
        />
        <polygon 
          points="90,50 90,70 30,80 30,40" 
          fill="#1A1F2C" 
          stroke="#9b87f5" 
          strokeWidth="2"
        />
        <rect 
          x="25" 
          y="55" 
          width="10" 
          height="10" 
          fill="#0EA5E9" 
        />
        
        {/* Engine glow */}
        <rect 
          x="5" 
          y="55" 
          width="10" 
          height="10" 
          fill="#ec4899" 
          opacity="0.8"
          className="animate-pulse"
        />
      </svg>
      
      {/* Health indicator */}
      <div 
        className="absolute bottom-[-10px] left-0 h-1 bg-red-500"
        style={{ 
          width: `${(player.health / 100) * player.width}px`,
          backgroundColor: player.health > 50 ? '#10b981' : player.health > 25 ? '#F97316' : '#ef4444'
        }}
      ></div>
    </div>
  );
};
