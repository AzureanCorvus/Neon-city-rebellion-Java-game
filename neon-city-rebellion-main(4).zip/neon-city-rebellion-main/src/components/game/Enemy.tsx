
import React from 'react';
import { GameEntity } from '../GameContainer';

interface EnemyProps {
  enemy: GameEntity;
}

export const Enemy: React.FC<EnemyProps> = ({ enemy }) => {
  // Generate a consistent enemy type based on the enemy ID
  const enemyIdNum = parseInt(enemy.id.split('-')[1], 10) || 0;
  const enemyType = ['drone', 'cyborg', 'hound'][enemyIdNum % 3];
  
  return (
    <div 
      className="absolute z-5 transition-transform"
      style={{
        left: `${enemy.x}px`,
        top: `${enemy.y}px`,
        width: `${enemy.width}px`,
        height: `${enemy.height}px`,
      }}
    >
      {enemyType === 'drone' && (
        <svg 
          viewBox="0 0 50 50" 
          className="w-full h-full"
          style={{ filter: 'drop-shadow(0 0 3px rgba(14, 165, 233, 0.7))' }}
        >
          <circle 
            cx="25" 
            cy="25" 
            r="15" 
            fill="#1A1F2C" 
            stroke="#0EA5E9" 
            strokeWidth="2"
          />
          <rect 
            x="5" 
            y="20" 
            width="10" 
            height="10" 
            fill="#1A1F2C" 
            stroke="#0EA5E9" 
            strokeWidth="2"
          />
          <rect 
            x="35" 
            y="20" 
            width="10" 
            height="10" 
            fill="#1A1F2C" 
            stroke="#0EA5E9" 
            strokeWidth="2"
          />
          <circle 
            cx="25" 
            cy="25" 
            r="5" 
            fill="#0EA5E9" 
            className="animate-pulse"
          />
        </svg>
      )}
      
      {enemyType === 'cyborg' && (
        <svg 
          viewBox="0 0 50 50" 
          className="w-full h-full"
          style={{ filter: 'drop-shadow(0 0 3px rgba(239, 68, 68, 0.7))' }}
        >
          <rect 
            x="10" 
            y="10" 
            width="30" 
            height="30" 
            fill="#1A1F2C" 
            stroke="#ef4444" 
            strokeWidth="2"
          />
          <circle 
            cx="20" 
            cy="20" 
            r="5" 
            fill="#ef4444" 
          />
          <circle 
            cx="30" 
            cy="20" 
            r="5" 
            fill="#ef4444" 
          />
          <rect 
            x="15" 
            y="30" 
            width="20" 
            height="5" 
            fill="#ef4444" 
          />
        </svg>
      )}
      
      {enemyType === 'hound' && (
        <svg 
          viewBox="0 0 50 50" 
          className="w-full h-full"
          style={{ filter: 'drop-shadow(0 0 3px rgba(249, 115, 22, 0.7))' }}
        >
          <polygon 
            points="10,25 20,10 40,10 40,40 20,40" 
            fill="#1A1F2C" 
            stroke="#F97316" 
            strokeWidth="2"
          />
          <circle 
            cx="35" 
            cy="20" 
            r="3" 
            fill="#F97316" 
          />
          <polygon 
            points="10,25 5,20 5,30" 
            fill="#1A1F2C" 
            stroke="#F97316" 
            strokeWidth="2"
          />
        </svg>
      )}
      
      {/* Health indicator */}
      <div 
        className="absolute bottom-[-5px] left-0 h-1 bg-red-500"
        style={{ 
          width: `${(enemy.health / (enemyType === 'cyborg' ? 50 : enemyType === 'drone' ? 30 : 40)) * enemy.width}px`,
          backgroundColor: enemy.health > 20 ? '#ef4444' : '#F97316'
        }}
      ></div>
    </div>
  );
};
