
import React from 'react';
import { PowerUpEntity } from '../GameContainer';

interface PowerUpProps {
  powerUp: PowerUpEntity;
}

export const PowerUp: React.FC<PowerUpProps> = ({ powerUp }) => {
  // Different styles based on powerup type
  const getColorForType = () => {
    switch (powerUp.type) {
      case 'health':
        return '#10b981'; // Green for health
      case 'ammo':
        return '#0EA5E9'; // Blue for ammo
      case 'weapon':
        return '#ec4899'; // Pink for weapon
      default:
        return '#9b87f5'; // Purple default
    }
  };
  
  const color = getColorForType();
  
  return (
    <div 
      className="absolute z-5 animate-pulse"
      style={{
        left: `${powerUp.x}px`,
        top: `${powerUp.y}px`,
        width: `${powerUp.width}px`,
        height: `${powerUp.height}px`,
      }}
    >
      <svg 
        viewBox="0 0 30 30" 
        className="w-full h-full"
        style={{ filter: `drop-shadow(0 0 5px ${color})` }}
      >
        <polygon 
          points="15,0 30,15 15,30 0,15" 
          fill="#1A1F2C" 
          stroke={color} 
          strokeWidth="2"
        />
        
        {powerUp.type === 'health' && (
          <rect x="10" y="5" width="10" height="20" fill={color} />
        )}
        
        {powerUp.type === 'health' && (
          <rect x="5" y="10" width="20" height="10" fill={color} />
        )}
        
        {powerUp.type === 'ammo' && (
          <>
            <rect x="10" y="8" width="10" height="14" fill={color} />
            <rect x="13" y="5" width="4" height="20" fill={color} />
          </>
        )}
        
        {powerUp.type === 'weapon' && (
          <>
            <circle cx="15" cy="15" r="7" fill={color} />
            <circle cx="15" cy="15" r="3" fill="#1A1F2C" />
          </>
        )}
      </svg>
    </div>
  );
};
