
import React from 'react';

export const Background: React.FC = () => {
  return (
    <div className="absolute inset-0 z-0">
      {/* Cyber city background */}
      <div 
        className="absolute inset-0 bg-cyber-black bg-cyber-grid bg-[length:40px_40px]"
        style={{
          backgroundPosition: '0 0',
          backgroundSize: '40px 40px'
        }}
      ></div>
      
      {/* Scanning effect */}
      <div 
        className="absolute inset-0 bg-scanning-line bg-[length:100%_2px] animate-scanning opacity-20"
        style={{
          backgroundRepeat: 'no-repeat',
          height: '2px',
          top: '50%'
        }}
      ></div>
      
      {/* Neon city buildings silhouette */}
      <div 
        className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-cyber-dark to-transparent z-0"
        style={{
          maskImage: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 1000 120\'%3E%3Cpath d=\'M0,120 L0,80 L50,80 L50,40 L100,40 L100,60 L150,60 L150,30 L200,30 L200,70 L250,70 L250,20 L300,20 L300,50 L350,50 L350,60 L400,60 L400,10 L450,10 L450,70 L500,70 L500,30 L550,30 L550,50 L600,50 L600,20 L650,20 L650,60 L700,60 L700,40 L750,40 L750,70 L800,70 L800,30 L850,30 L850,60 L900,60 L900,20 L950,20 L950,50 L1000,50 L1000,120 Z\' fill=\'%23000\'/%3E%3C/svg%3E")',
          maskSize: 'cover',
          maskRepeat: 'no-repeat',
          backgroundColor: '#1A1F2C'
        }}
      ></div>
      
      {/* Far distant lights */}
      {Array.from({ length: 30 }).map((_, index) => {
        const size = Math.random() * 2 + 1; // 1-3px
        const x = Math.random() * 100; // 0-100%
        const y = Math.random() * 60 + 10; // 10-70%
        const color = ['#9b87f5', '#0EA5E9', '#ec4899', '#F97316'][Math.floor(Math.random() * 4)];
        const animationDuration = Math.random() * 3 + 2; // 2-5s
        
        return (
          <div 
            key={index} 
            className="absolute rounded-full z-0"
            style={{
              width: `${size}px`,
              height: `${size}px`,
              left: `${x}%`,
              top: `${y}%`,
              backgroundColor: color,
              boxShadow: `0 0 ${size * 2}px ${color}`,
              animation: `neon-pulse ${animationDuration}s infinite alternate`,
              opacity: Math.random() * 0.5 + 0.5 // 0.5-1
            }}
          ></div>
        );
      })}
    </div>
  );
};
