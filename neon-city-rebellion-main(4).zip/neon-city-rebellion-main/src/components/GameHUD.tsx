
import React from 'react';
import { Progress } from '@/components/ui/progress';

interface GameHUDProps {
  health: number;
  ammo: number;
  maxAmmo: number;
  reload: boolean;
  reloadProgress: number;
  score: number;
  level: number;
  weaponType: 'basic' | 'rapid' | 'plasma';
}

export const GameHUD: React.FC<GameHUDProps> = ({
  health,
  ammo,
  maxAmmo,
  reload,
  reloadProgress,
  score,
  level,
  weaponType
}) => {
  // Determine weapon color based on type
  const weaponColor = 
    weaponType === 'basic' 
      ? 'text-cyber-blue' 
      : weaponType === 'rapid' 
        ? 'text-cyber-green' 
        : 'text-cyber-purple';

  return (
    <div className="absolute top-0 left-0 w-full p-4 flex justify-between items-start">
      {/* Health and Weapon Display */}
      <div className="flex flex-col items-start">
        <div className="mb-1 flex justify-between w-36">
          <span className="text-white text-xs">HEALTH</span>
          <span className="text-white text-xs">{health}%</span>
        </div>
        <Progress 
          value={health} 
          className="w-36 h-2 bg-cyber-dark border border-white/10" 
          indicatorClassName={`${health > 50 ? 'bg-cyber-green' : health > 25 ? 'bg-cyber-orange' : 'bg-cyber-red'}`}
        />
        
        <div className="mt-3 mb-1 flex justify-between w-36">
          <span className="text-white text-xs">AMMO</span>
          <span className="text-white text-xs">{ammo}/{maxAmmo}</span>
        </div>
        {reload ? (
          <Progress 
            value={reloadProgress} 
            className="w-36 h-2 bg-cyber-dark border border-white/10" 
            indicatorClassName="bg-cyber-orange"
          />
        ) : (
          <Progress 
            value={(ammo / maxAmmo) * 100} 
            className="w-36 h-2 bg-cyber-dark border border-white/10" 
            indicatorClassName="bg-cyber-blue"
          />
        )}
        
        <div className="mt-3 flex items-center">
          <span className="text-white text-xs mr-2">WEAPON:</span>
          <span className={`text-sm font-bold ${weaponColor}`}>
            {weaponType.toUpperCase()}
          </span>
        </div>
      </div>
      
      {/* Score Display */}
      <div className="cyber-panel px-3 py-1 rounded">
        <div className="flex flex-col items-end">
          <div className="text-sm text-white">LEVEL: <span className="text-cyber-purple">{level}</span></div>
          <div className="text-sm text-white">SCORE: <span className="text-cyber-purple">{score}</span></div>
        </div>
      </div>
    </div>
  );
};
