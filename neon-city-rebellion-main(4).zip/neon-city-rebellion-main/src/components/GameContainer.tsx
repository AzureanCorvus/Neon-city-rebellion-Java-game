
import React, { useRef, useEffect, useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { GameHUD } from './GameHUD';
import { Player } from './game/Player';
import { Enemy } from './game/Enemy';
import { Bullet } from './game/Bullet';
import { PowerUp } from './game/PowerUp';
import { Background } from './game/Background';

export interface GameEntity {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  health: number;
  speed: number;
  active: boolean;
}

export interface BulletEntity {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
  damage: number;
  isPlayerBullet: boolean;
  active: boolean;
}

export interface PowerUpEntity {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'health' | 'ammo' | 'weapon';
  active: boolean;
}

const GameContainer: React.FC = () => {
  const gameContainerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  // Game state
  const [gameActive, setGameActive] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  
  // Game entities
  const [player, setPlayer] = useState<GameEntity>({
    id: 'player',
    x: 100,
    y: 300,
    width: 50,
    height: 60,
    health: 100,
    speed: 5,
    active: true
  });
  
  const [enemies, setEnemies] = useState<GameEntity[]>([]);
  const [bullets, setBullets] = useState<BulletEntity[]>([]);
  const [powerUps, setPowerUps] = useState<PowerUpEntity[]>([]);
  
  // Game variables
  const [ammo, setAmmo] = useState(30);
  const [maxAmmo, setMaxAmmo] = useState(30);
  const [reload, setReload] = useState(false);
  const [reloadTime, setReloadTime] = useState(0);
  const [weaponType, setWeaponType] = useState<'basic' | 'rapid' | 'plasma'>('basic');
  
  // Get game container dimensions
  const getGameDimensions = () => {
    if (gameContainerRef.current) {
      return {
        width: gameContainerRef.current.clientWidth,
        height: gameContainerRef.current.clientHeight
      };
    }
    return { width: 800, height: 600 };
  };
  
  // Start game function
  const startGame = () => {
    setGameActive(true);
    setGameOver(false);
    setScore(0);
    setLevel(1);
    setPlayer({
      id: 'player',
      x: 100,
      y: getGameDimensions().height / 2,
      width: 50,
      height: 60,
      health: 100,
      speed: 5,
      active: true
    });
    setEnemies([]);
    setBullets([]);
    setPowerUps([]);
    setAmmo(30);
    setMaxAmmo(30);
    setReload(false);
    setReloadTime(0);
    setWeaponType('basic');
    
    toast({
      title: "Game Started",
      description: "Defend the cyberpunk city!",
    });
  };
  
  // Game over function
  const handleGameOver = () => {
    setGameActive(false);
    setGameOver(true);
    toast({
      title: "Game Over",
      description: `Your final score: ${score}`,
      variant: "destructive"
    });
  };
  
  // Player movement handlers
  const [keys, setKeys] = useState({
    ArrowLeft: false,
    ArrowRight: false,
    ArrowUp: false,
    ArrowDown: false,
    ' ': false, // Space for shooting
  });
  
  // Setup key event listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (Object.keys(keys).includes(e.key)) {
        e.preventDefault();
        setKeys(prev => ({ ...prev, [e.key]: true }));
      }
    };
    
    const handleKeyUp = (e: KeyboardEvent) => {
      if (Object.keys(keys).includes(e.key)) {
        e.preventDefault();
        setKeys(prev => ({ ...prev, [e.key]: false }));
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);
  
  // Shoot function
  const shoot = () => {
    if (ammo <= 0 || reload) {
      // Start reloading if no ammo
      if (!reload && ammo <= 0) {
        setReload(true);
        setReloadTime(1500); // 1.5 seconds reload time
      }
      return;
    }
    
    const newBullet: BulletEntity = {
      id: `bullet-${Date.now()}-${Math.random()}`,
      x: player.x + player.width,
      y: player.y + player.height / 2 - 5,
      width: 20,
      height: 10,
      speed: 10,
      damage: weaponType === 'basic' ? 10 : weaponType === 'rapid' ? 7 : 15,
      isPlayerBullet: true,
      active: true
    };
    
    setBullets(prev => [...prev, newBullet]);
    setAmmo(prev => prev - 1);
  };
  
  // Spawn enemy
  const spawnEnemy = () => {
    const dimensions = getGameDimensions();
    const enemyTypes = ['drone', 'cyborg', 'hound'];
    const enemyType = enemyTypes[Math.floor(Math.random() * enemyTypes.length)];
    
    const newEnemy: GameEntity = {
      id: `enemy-${Date.now()}-${Math.random()}`,
      x: dimensions.width,
      y: Math.random() * (dimensions.height - 60),
      width: 50,
      height: 50,
      health: enemyType === 'drone' ? 30 : enemyType === 'cyborg' ? 50 : 40,
      speed: enemyType === 'drone' ? 3 : enemyType === 'cyborg' ? 1.5 : 2.5,
      active: true
    };
    
    setEnemies(prev => [...prev, newEnemy]);
  };
  
  // Spawn power up
  const spawnPowerUp = () => {
    const dimensions = getGameDimensions();
    const powerUpTypes: ('health' | 'ammo' | 'weapon')[] = ['health', 'ammo', 'weapon'];
    const powerUpType = powerUpTypes[Math.floor(Math.random() * powerUpTypes.length)];
    
    const newPowerUp: PowerUpEntity = {
      id: `powerup-${Date.now()}-${Math.random()}`,
      x: Math.random() * (dimensions.width - 100) + 50,
      y: Math.random() * (dimensions.height - 60),
      width: 30,
      height: 30,
      type: powerUpType,
      active: true
    };
    
    setPowerUps(prev => [...prev, newPowerUp]);
  };
  
  // Collision detection
  const checkCollision = (rect1: { x: number, y: number, width: number, height: number }, 
                         rect2: { x: number, y: number, width: number, height: number }) => {
    return rect1.x < rect2.x + rect2.width &&
           rect1.x + rect1.width > rect2.x &&
           rect1.y < rect2.y + rect2.height &&
           rect1.y + rect1.height > rect2.y;
  };
  
  // Game update loop
  useEffect(() => {
    if (!gameActive) return;
    
    const dimensions = getGameDimensions();
    
    // Update game at 60fps
    const gameLoop = setInterval(() => {
      // Update player position based on key presses
      if (gameActive) {
        setPlayer(prev => {
          const newX = keys.ArrowLeft 
            ? Math.max(0, prev.x - prev.speed) 
            : keys.ArrowRight 
              ? Math.min(dimensions.width - prev.width, prev.x + prev.speed) 
              : prev.x;
          
          const newY = keys.ArrowUp 
            ? Math.max(0, prev.y - prev.speed) 
            : keys.ArrowDown 
              ? Math.min(dimensions.height - prev.height, prev.y + prev.speed) 
              : prev.y;
          
          return { ...prev, x: newX, y: newY };
        });
        
        // Handle shooting
        if (keys[' ']) {
          // For rapid weapon, shoot faster
          if (weaponType === 'rapid') {
            if (Math.random() > 0.7) shoot();
          } else if (Math.random() > 0.8) {
            shoot();
          }
        }
        
        // Update bullets
        setBullets(prev => prev.map(bullet => {
          if (!bullet.active) return bullet;
          
          let newX = bullet.isPlayerBullet 
            ? bullet.x + bullet.speed 
            : bullet.x - bullet.speed;
          
          // Remove bullets that go off screen
          if (newX > dimensions.width || newX < -bullet.width) {
            return { ...bullet, active: false };
          }
          
          return { ...bullet, x: newX };
        }).filter(bullet => bullet.active));
        
        // Update enemies
        setEnemies(prev => prev.map(enemy => {
          if (!enemy.active) return enemy;
          
          // Move enemy towards player
          let newX = enemy.x - enemy.speed;
          let newY = enemy.y;
          
          // Simple AI: Some enemies track player vertically
          if (Math.random() > 0.7) {
            if (enemy.y < player.y) newY += enemy.speed * 0.5;
            else if (enemy.y > player.y) newY -= enemy.speed * 0.5;
          }
          
          // Enemy shooting logic - randomly fire at player
          if (Math.random() > 0.99) {
            const enemyBullet: BulletEntity = {
              id: `enemy-bullet-${Date.now()}-${Math.random()}`,
              x: enemy.x,
              y: enemy.y + enemy.height / 2,
              width: 15,
              height: 5,
              speed: 5,
              damage: 10,
              isPlayerBullet: false,
              active: true
            };
            
            setBullets(bullets => [...bullets, enemyBullet]);
          }
          
          // Remove enemies that go off screen
          if (newX < -enemy.width) {
            return { ...enemy, active: false };
          }
          
          return { ...enemy, x: newX, y: newY };
        }).filter(enemy => enemy.active));
        
        // Check bullet collisions with enemies
        setBullets(prev => {
          const updatedBullets = [...prev];
          
          for (let i = 0; i < updatedBullets.length; i++) {
            const bullet = updatedBullets[i];
            
            if (!bullet.active || !bullet.isPlayerBullet) continue;
            
            setEnemies(enemies => {
              return enemies.map(enemy => {
                if (!enemy.active) return enemy;
                
                if (checkCollision(bullet, enemy)) {
                  // Bullet hit enemy
                  updatedBullets[i] = { ...bullet, active: false };
                  setScore(prev => prev + 10);
                  
                  const newHealth = enemy.health - bullet.damage;
                  if (newHealth <= 0) {
                    // Enemy defeated
                    setScore(prev => prev + 50);
                    
                    // Spawn power up on enemy death with low probability
                    if (Math.random() > 0.9) {
                      spawnPowerUp();
                    }
                    
                    return { ...enemy, health: 0, active: false };
                  }
                  
                  return { ...enemy, health: newHealth };
                }
                return enemy;
              });
            });
          }
          
          return updatedBullets;
        });
        
        // Check enemy bullet collisions with player
        setBullets(prev => {
          const updatedBullets = [...prev];
          
          for (let i = 0; i < updatedBullets.length; i++) {
            const bullet = updatedBullets[i];
            
            if (!bullet.active || bullet.isPlayerBullet) continue;
            
            if (checkCollision(bullet, player)) {
              // Enemy bullet hit player
              updatedBullets[i] = { ...bullet, active: false };
              
              setPlayer(player => {
                const newHealth = player.health - bullet.damage;
                
                if (newHealth <= 0 && player.active) {
                  handleGameOver();
                  return { ...player, health: 0, active: false };
                }
                
                return { ...player, health: newHealth };
              });
            }
          }
          
          return updatedBullets;
        });
        
        // Check enemy collisions with player
        setEnemies(prev => {
          return prev.map(enemy => {
            if (!enemy.active || !player.active) return enemy;
            
            if (checkCollision(enemy, player)) {
              // Enemy collided with player
              setPlayer(player => {
                const newHealth = player.health - 20;
                
                if (newHealth <= 0 && player.active) {
                  handleGameOver();
                  return { ...player, health: 0, active: false };
                }
                
                return { ...player, health: newHealth };
              });
              
              return { ...enemy, active: false };
            }
            
            return enemy;
          });
        });
        
        // Check power up collisions with player
        setPowerUps(prev => {
          return prev.map(powerUp => {
            if (!powerUp.active || !player.active) return powerUp;
            
            if (checkCollision(powerUp, player)) {
              // Power up collected
              if (powerUp.type === 'health') {
                setPlayer(player => ({
                  ...player,
                  health: Math.min(100, player.health + 25)
                }));
                toast({
                  title: "Health Restored",
                  description: "+25 Health",
                });
              } else if (powerUp.type === 'ammo') {
                setAmmo(maxAmmo);
                toast({
                  title: "Ammo Restored",
                  description: "Ammo fully restocked",
                });
              } else if (powerUp.type === 'weapon') {
                const weapons: ('basic' | 'rapid' | 'plasma')[] = ['basic', 'rapid', 'plasma'];
                const newWeapon = weapons[(weapons.indexOf(weaponType) + 1) % weapons.length];
                setWeaponType(newWeapon);
                toast({
                  title: "Weapon Upgraded",
                  description: `New weapon: ${newWeapon.toUpperCase()}`,
                });
              }
              
              return { ...powerUp, active: false };
            }
            
            return powerUp;
          }).filter(powerUp => powerUp.active);
        });
        
        // Spawn enemies based on level and score
        if (Math.random() > 0.98 - (level * 0.01)) {
          spawnEnemy();
        }
        
        // Handle reloading
        if (reload) {
          setReloadTime(prev => {
            if (prev <= 0) {
              setReload(false);
              setAmmo(maxAmmo);
              return 0;
            }
            return prev - 16; // ~60fps, so 16ms per frame
          });
        }
        
        // Level progression based on score
        const newLevel = Math.floor(score / 500) + 1;
        if (newLevel > level) {
          setLevel(newLevel);
          toast({
            title: "Level Up!",
            description: `You've reached level ${newLevel}`,
          });
        }
      }
    }, 16); // ~60fps
    
    return () => clearInterval(gameLoop);
  }, [gameActive, keys, player, weaponType, reload, level]);
  
  return (
    <div className="w-full p-2 lg:p-4">
      <div
        ref={gameContainerRef}
        id="game-container"
        className="relative mx-auto w-full h-[600px] cyber-panel rounded-md overflow-hidden bg-cyber-dark"
      >
        {gameActive ? (
          <>
            <Background />
            
            {/* Render power ups */}
            {powerUps.map(powerUp => (
              <PowerUp key={powerUp.id} powerUp={powerUp} />
            ))}
            
            {/* Render bullets */}
            {bullets.map(bullet => (
              <Bullet key={bullet.id} bullet={bullet} />
            ))}
            
            {/* Render enemies */}
            {enemies.map(enemy => (
              <Enemy key={enemy.id} enemy={enemy} />
            ))}
            
            {/* Render player */}
            <Player player={player} />
            
            {/* Game HUD */}
            <GameHUD 
              health={player.health} 
              ammo={ammo}
              maxAmmo={maxAmmo}
              reload={reload}
              reloadProgress={reload ? ((maxAmmo - reloadTime / 1500 * maxAmmo) / maxAmmo) * 100 : 0}
              score={score}
              level={level}
              weaponType={weaponType}
            />
          </>
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-cyber-black/70 backdrop-blur-sm z-10">
            <h1 className="text-5xl font-bold text-cyber-purple animate-neon-pulse mb-2">NEON CITY</h1>
            <h2 className="text-3xl font-bold text-cyber-blue mb-12">REBELLION</h2>
            {gameOver ? (
              <>
                <p className="text-2xl text-white mb-2">Game Over</p>
                <p className="text-xl text-cyber-purple mb-8">Final Score: {score}</p>
              </>
            ) : (
              <p className="text-xl text-white mb-8">Defend the cyberpunk city from mechanical enemies!</p>
            )}
            <div className="flex gap-4">
              <Button 
                onClick={startGame} 
                className="cyber-button text-xl px-8 py-6"
              >
                {gameOver ? 'Try Again' : 'Start Game'}
              </Button>
              {gameOver && (
                <Button
                  onClick={() => {
                    setGameOver(false);
                    setScore(0);
                  }}
                  variant="outline"
                  className="text-xl px-8 py-6 border-cyber-blue text-cyber-blue hover:bg-cyber-blue/20"
                >
                  Main Menu
                </Button>
              )}
            </div>
            
            <div className="mt-12 text-sm text-muted-foreground">
              <p>Controls: Arrow keys to move, Space to shoot</p>
              <p className="mt-2">Collect power-ups for health, ammo and weapon upgrades</p>
            </div>
          </div>
        )}
      </div>
      
      {/* Game Controls - Mobile Support */}
      {gameActive && (
        <div className="lg:hidden mt-4 grid grid-cols-3 gap-2">
          <div className="flex justify-center">
            <Button 
              onTouchStart={() => setKeys(prev => ({ ...prev, ArrowLeft: true }))}
              onTouchEnd={() => setKeys(prev => ({ ...prev, ArrowLeft: false }))}
              className="cyber-button w-16 h-16 flex items-center justify-center"
            >
              ←
            </Button>
          </div>
          <div className="flex justify-center">
            <div className="grid grid-cols-1 gap-2">
              <Button 
                onTouchStart={() => setKeys(prev => ({ ...prev, ArrowUp: true }))}
                onTouchEnd={() => setKeys(prev => ({ ...prev, ArrowUp: false }))}
                className="cyber-button w-16 h-16 flex items-center justify-center"
              >
                ↑
              </Button>
              <Button 
                onTouchStart={() => setKeys(prev => ({ ...prev, ArrowDown: true }))}
                onTouchEnd={() => setKeys(prev => ({ ...prev, ArrowDown: false }))}
                className="cyber-button w-16 h-16 flex items-center justify-center"
              >
                ↓
              </Button>
            </div>
          </div>
          <div className="flex justify-center">
            <div className="grid grid-cols-1 gap-2">
              <Button 
                onTouchStart={() => setKeys(prev => ({ ...prev, ArrowRight: true }))}
                onTouchEnd={() => setKeys(prev => ({ ...prev, ArrowRight: false }))}
                className="cyber-button w-16 h-16 flex items-center justify-center"
              >
                →
              </Button>
              <Button 
                onTouchStart={() => setKeys(prev => ({ ...prev, ' ': true }))}
                onTouchEnd={() => setKeys(prev => ({ ...prev, ' ': false }))}
                className="cyber-button w-16 h-16 flex items-center justify-center bg-cyber-orange/20 border-cyber-orange text-cyber-orange"
              >
                FIRE
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GameContainer;
